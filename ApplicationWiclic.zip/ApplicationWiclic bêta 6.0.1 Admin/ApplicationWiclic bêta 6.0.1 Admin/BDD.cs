﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 11:58
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using MySql.Data.MySqlClient;

namespace ApplicationWiclic_bêta_6._.__Admin
{
	/// <summary>
	/// Description of BDD.
	/// </summary>
public static class BDD  {
		 public static MySqlConnection maconnexion; // connexion est en static 
			 public static void connexion( ) {
		 	String fichier = System.IO.File.ReadAllText ("connexHostIP.ini");
			 String chaineConnexion;
			 chaineConnexion = "data source="+fichier+"; initial catalog=wiclic;user id=Administrateur;password= Z4FdO*D0@]UMJh6l;"; // permet de se connecter a la BDD
			 maconnexion = new MySqlConnection(chaineConnexion); // execute la commande de connexion a la BDD
			 maconnexion.Open( ); // ouvre la connexion
			 } // Fin méthode connexion
	}
	}
