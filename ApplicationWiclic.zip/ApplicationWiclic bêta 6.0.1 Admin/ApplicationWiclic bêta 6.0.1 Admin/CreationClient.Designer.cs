﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 12:00
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic_bêta_6._.__Admin
{
	partial class CreationClient
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.Button bouton_Creation;
		private System.Windows.Forms.Button bouton_annuler;
		private System.Windows.Forms.ComboBox comboBox1;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreationClient));
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.bouton_annuler = new System.Windows.Forms.Button();
			this.bouton_Creation = new System.Windows.Forms.Button();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// comboBox1
			// 
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
			"OUI",
			"NON"});
			this.comboBox1.Location = new System.Drawing.Point(372, 347);
			this.comboBox1.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(418, 39);
			this.comboBox1.TabIndex = 33;
			// 
			// bouton_annuler
			// 
			this.bouton_annuler.BackColor = System.Drawing.Color.LightBlue;
			this.bouton_annuler.Location = new System.Drawing.Point(808, 271);
			this.bouton_annuler.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.bouton_annuler.Name = "bouton_annuler";
			this.bouton_annuler.Size = new System.Drawing.Size(261, 115);
			this.bouton_annuler.TabIndex = 32;
			this.bouton_annuler.Text = "ANNULER";
			this.bouton_annuler.UseVisualStyleBackColor = false;
			this.bouton_annuler.Click += new System.EventHandler(this.Bouton_annulerClick);
			// 
			// bouton_Creation
			// 
			this.bouton_Creation.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_Creation.Location = new System.Drawing.Point(808, 118);
			this.bouton_Creation.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.bouton_Creation.Name = "bouton_Creation";
			this.bouton_Creation.Size = new System.Drawing.Size(261, 115);
			this.bouton_Creation.TabIndex = 31;
			this.bouton_Creation.Text = "Création du Client";
			this.bouton_Creation.UseVisualStyleBackColor = false;
			this.bouton_Creation.Click += new System.EventHandler(this.Bouton_CreationClick);
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(372, 271);
			this.textBox3.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(418, 38);
			this.textBox3.TabIndex = 30;
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(372, 195);
			this.textBox2.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(418, 38);
			this.textBox2.TabIndex = 29;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(372, 118);
			this.textBox1.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(418, 38);
			this.textBox1.TabIndex = 28;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(169, 347);
			this.label5.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(185, 33);
			this.label5.TabIndex = 27;
			this.label5.Text = "Abonnement";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(233, 271);
			this.label4.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(104, 38);
			this.label4.TabIndex = 26;
			this.label4.Text = "E-mail";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(208, 195);
			this.label3.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(129, 38);
			this.label3.TabIndex = 25;
			this.label3.Text = "Prenom";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(123, 118);
			this.label2.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(231, 38);
			this.label2.TabIndex = 24;
			this.label2.Text = "Nom de Famille";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(355, 9);
			this.label1.Margin = new System.Windows.Forms.Padding(14, 0, 14, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(426, 42);
			this.label1.TabIndex = 23;
			this.label1.Text = "Insertion du Client dans la BDD";
			// 
			// CreationClient
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 31F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumAquamarine;
			this.ClientSize = new System.Drawing.Size(1124, 477);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.bouton_annuler);
			this.Controls.Add(this.bouton_Creation);
			this.Controls.Add(this.textBox3);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ForeColor = System.Drawing.SystemColors.Window;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.MaximumSize = new System.Drawing.Size(1140, 516);
			this.MinimumSize = new System.Drawing.Size(1140, 516);
			this.Name = "CreationClient";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "CreationClient";
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
