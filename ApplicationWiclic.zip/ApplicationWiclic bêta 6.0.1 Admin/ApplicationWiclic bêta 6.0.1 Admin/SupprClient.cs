﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 12:02
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace ApplicationWiclic_bêta_6._.__Admin
{
	/// <summary>
	/// Description of SupprClient.
	/// </summary>
	public partial class SupprClient : Form
	{
		public SupprClient()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		Utilisateur ApplicationWiclic = new Utilisateur ();
		
		void SupprClientLoad(object sender, EventArgs e)
		{
			listView1.GridLines = true;
			listView1.View = View.Details;
			listView1.Columns.Add("",0);
			listView1.Columns.Add("ID Client",150);
			listView1.Columns.Add("Nom de Famille",250);
			listView1.Columns.Add("Prenom",150);
			listView1.Columns.Add("E-Mail",300);
			listView1.Columns.Add(" Est Abonné ?",350);

		}
		void Bouton_ChercheCliClick(object sender, EventArgs e)
		{
			try{
			string nom = textBox_Recherche.Text;
			string fichier = System.IO.File.ReadAllText ("connexHostIP.ini");
			string con = "data source="+fichier+"; initial catalog=wiclic;user id=root;password=;";
			MySqlConnection cnn = new MySqlConnection(con);
			cnn.Open();
			string sql = "SELECT `num`, `nom_de_famille`, `prenom`, `adresse_mail`, `abonnement` FROM client WHERE nom_de_famille LIKE '%"+nom+"%'";
			MySqlCommand cmd = new MySqlCommand(sql,cnn);
			MySqlDataReader rd;
			rd = cmd.ExecuteReader();
			listView1.Items.Clear();
			while (rd.Read())
			{
				ListViewItem lv = new ListViewItem();
				lv.SubItems.Add(rd.GetInt32(0).ToString());
				lv.SubItems.Add(rd.GetString(1).ToString());
				lv.SubItems.Add(rd.GetString(2).ToString());
				lv.SubItems.Add(rd.GetString(3).ToString());
				lv.SubItems.Add(rd.GetString(4).ToString());

				listView1.Items.Add(lv);
			}
			
			rd.Close();
			cmd.Dispose();
			cnn.Close();
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_SupprClick(object sender, EventArgs e)
		{
			try{
			ApplicationWiclic.setnum (int.Parse(textBox3.Text));
			BDD.connexion();
			ApplicationWiclic.delete();
			textBox3.Text=String.Empty;
			MessageBox.Show("Demande supprimer");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_annulerClick(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
