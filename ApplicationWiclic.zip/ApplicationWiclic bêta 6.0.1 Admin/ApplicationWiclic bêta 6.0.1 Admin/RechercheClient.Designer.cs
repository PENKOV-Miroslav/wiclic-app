﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 12:01
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic_bêta_6._.__Admin
{
	partial class RechercheClient
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button bouton_annuler;
		private System.Windows.Forms.Button bouton_Cherche;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ListView listView1;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RechercheClient));
			this.bouton_annuler = new System.Windows.Forms.Button();
			this.bouton_Cherche = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.listView1 = new System.Windows.Forms.ListView();
			this.SuspendLayout();
			// 
			// bouton_annuler
			// 
			this.bouton_annuler.BackColor = System.Drawing.Color.LightBlue;
			this.bouton_annuler.Location = new System.Drawing.Point(993, 137);
			this.bouton_annuler.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
			this.bouton_annuler.Name = "bouton_annuler";
			this.bouton_annuler.Size = new System.Drawing.Size(258, 84);
			this.bouton_annuler.TabIndex = 32;
			this.bouton_annuler.Text = "ANNULER";
			this.bouton_annuler.UseVisualStyleBackColor = false;
			this.bouton_annuler.Click += new System.EventHandler(this.Bouton_annulerClick);
			// 
			// bouton_Cherche
			// 
			this.bouton_Cherche.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_Cherche.Location = new System.Drawing.Point(723, 137);
			this.bouton_Cherche.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
			this.bouton_Cherche.Name = "bouton_Cherche";
			this.bouton_Cherche.Size = new System.Drawing.Size(258, 84);
			this.bouton_Cherche.TabIndex = 31;
			this.bouton_Cherche.Text = "Chercher un Client";
			this.bouton_Cherche.UseVisualStyleBackColor = false;
			this.bouton_Cherche.Click += new System.EventHandler(this.Bouton_ChercheClick);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(226, 164);
			this.textBox1.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(455, 31);
			this.textBox1.TabIndex = 28;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(28, 164);
			this.label2.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(184, 31);
			this.label2.TabIndex = 24;
			this.label2.Text = "Nom de Famille";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(359, 11);
			this.label1.Margin = new System.Windows.Forms.Padding(11, 0, 11, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(404, 35);
			this.label1.TabIndex = 23;
			this.label1.Text = "Recherche d\' un Client dans la BDD";
			// 
			// listView1
			// 
			this.listView1.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.listView1.FullRowSelect = true;
			this.listView1.Location = new System.Drawing.Point(12, 267);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(1350, 446);
			this.listView1.TabIndex = 33;
			this.listView1.UseCompatibleStateImageBehavior = false;
			// 
			// RechercheClient
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumAquamarine;
			this.ClientSize = new System.Drawing.Size(1374, 732);
			this.Controls.Add(this.listView1);
			this.Controls.Add(this.bouton_annuler);
			this.Controls.Add(this.bouton_Cherche);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ForeColor = System.Drawing.SystemColors.Window;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
			this.MaximumSize = new System.Drawing.Size(1390, 771);
			this.MinimumSize = new System.Drawing.Size(1390, 771);
			this.Name = "RechercheClient";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "RechercheClient";
			this.Load += new System.EventHandler(this.RechercheClientLoad);
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
