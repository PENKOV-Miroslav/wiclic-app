﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 12:06
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace ApplicationWiclic_bêta_6._.__Admin
{
	/// <summary>
	/// Description of Manuel.
	/// </summary>
	public partial class Manuel : Form
	{
		public Manuel()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Bouton_manuelClientClick(object sender, EventArgs e)
		{
			try{
		
        System.Diagnostics.Process.Start(@"https://www.wiclic.fr/documents/Manuel-Client.pdf");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_manuelAdminClick(object sender, EventArgs e)
		{
			try{
		
        System.Diagnostics.Process.Start(@"https://www.wiclic.fr/documents/Manuel-Admin.pdf");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
	}
}
