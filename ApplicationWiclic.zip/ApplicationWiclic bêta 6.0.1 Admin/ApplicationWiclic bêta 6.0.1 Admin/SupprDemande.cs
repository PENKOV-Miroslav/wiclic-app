﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 28/06/2022
 * Heure: 14:48
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ApplicationWiclic_bêta_6._.__Admin
{
	/// <summary>
	/// Description of SupprDemande.
	/// </summary>
	public partial class SupprDemande : Form
	{
		public SupprDemande()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		Utilisateur ApplicationWiclic = new Utilisateur ();
		void Bouton_SupprDemandeClick(object sender, EventArgs e)
		{
			try{
			ApplicationWiclic.setnum (int.Parse(textBox1.Text));
			BDD.connexion();
			ApplicationWiclic.deleteDemandeClient();
			textBox1.Text=String.Empty;
			MessageBox.Show("Demande supprimer");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
			
	}
}
