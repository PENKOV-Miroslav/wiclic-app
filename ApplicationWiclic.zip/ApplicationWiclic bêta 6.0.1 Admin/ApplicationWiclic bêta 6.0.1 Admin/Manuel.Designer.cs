﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 12:06
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic_bêta_6._.__Admin
{
	partial class Manuel
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button bouton_manuelClient;
		private System.Windows.Forms.Button bouton_manuelAdmin;
		private System.Windows.Forms.Label label1;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Manuel));
			this.bouton_manuelClient = new System.Windows.Forms.Button();
			this.bouton_manuelAdmin = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// bouton_manuelClient
			// 
			this.bouton_manuelClient.Image = ((System.Drawing.Image)(resources.GetObject("bouton_manuelClient.Image")));
			this.bouton_manuelClient.Location = new System.Drawing.Point(88, 68);
			this.bouton_manuelClient.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
			this.bouton_manuelClient.Name = "bouton_manuelClient";
			this.bouton_manuelClient.Size = new System.Drawing.Size(302, 205);
			this.bouton_manuelClient.TabIndex = 0;
			this.bouton_manuelClient.Text = "Manuel Client";
			this.bouton_manuelClient.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_manuelClient.UseVisualStyleBackColor = true;
			this.bouton_manuelClient.Click += new System.EventHandler(this.Bouton_manuelClientClick);
			// 
			// bouton_manuelAdmin
			// 
			this.bouton_manuelAdmin.Image = ((System.Drawing.Image)(resources.GetObject("bouton_manuelAdmin.Image")));
			this.bouton_manuelAdmin.Location = new System.Drawing.Point(441, 68);
			this.bouton_manuelAdmin.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
			this.bouton_manuelAdmin.Name = "bouton_manuelAdmin";
			this.bouton_manuelAdmin.Size = new System.Drawing.Size(302, 205);
			this.bouton_manuelAdmin.TabIndex = 1;
			this.bouton_manuelAdmin.Text = "Manuel Admin";
			this.bouton_manuelAdmin.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_manuelAdmin.UseVisualStyleBackColor = true;
			this.bouton_manuelAdmin.Click += new System.EventHandler(this.Bouton_manuelAdminClick);
			// 
			// label1
			// 
			this.label1.ForeColor = System.Drawing.SystemColors.Window;
			this.label1.Location = new System.Drawing.Point(171, 9);
			this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(484, 42);
			this.label1.TabIndex = 2;
			this.label1.Text = "Manuel d\' utilisation du logiciel Client ou  Admin";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Manuel
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumAquamarine;
			this.ClientSize = new System.Drawing.Size(837, 319);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.bouton_manuelAdmin);
			this.Controls.Add(this.bouton_manuelClient);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
			this.MaximumSize = new System.Drawing.Size(853, 358);
			this.MinimumSize = new System.Drawing.Size(853, 358);
			this.Name = "Manuel";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Manuel";
			this.ResumeLayout(false);

		}
	}
}
