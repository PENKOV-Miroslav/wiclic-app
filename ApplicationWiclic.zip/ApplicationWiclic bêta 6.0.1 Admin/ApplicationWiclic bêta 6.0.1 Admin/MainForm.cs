﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 11:33
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ApplicationWiclic_bêta_6._.__Admin
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Bouton_créationClick(object sender, EventArgs e) // Ce bouton permet d'afficher le formulaire de création d'un client
		{
			try{
			this.Hide(); 								// Cela permet de cacher la fenetre 'mere' et ainsi par la suite afficher en une autre
			var CreationClient = new CreationClient(); // On instancie une nouvelle objet (fenetre) de creation du Client
			CreationClient.ShowDialog(); 			  // Affiche le formulaire comme une boîte de dialogue modale 
			CreationClient = null;					 // le nouveau objet a pour valeur null
			this.Show();
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }			// Montre le formulaire
		}
		void Bouton_modifCliClick(object sender, EventArgs e) // Ce bouton permet d'afficher le formulaire de modification d'un client
		{
			try{
			this.Hide();										// Cela permet de cacher la fenetre 'mere' et ainsi par la suite afficher en une autre
			var ModificationClient = new ModificationClient(); // On instancie une nouvelle objet (fenetre) de modification du Client
			ModificationClient.ShowDialog();					// Affiche le formulaire comme une boîte de dialogue modale
			ModificationClient = null;							// le nouveau objet a pour valeur null
			this.Show();
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }			// Montre le formulaire
		}
		void Bouton_rechCliClick(object sender, EventArgs e) // Ce bouton permet d'afficher le formulaire de recherche d'un client
		{
			try{
			this.Hide();
			var RechercheClient = new RechercheClient();
			RechercheClient.ShowDialog();
			RechercheClient = null;
			this.Show();
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_supprCliClick(object sender, EventArgs e) // Ce bouton permet d'afficher le formulaire de suppression d'un client
		{
			try{
			this.Hide();
			var SupprClient = new SupprClient();
			SupprClient.ShowDialog();
			SupprClient = null;
			this.Show();
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_supportClick(object sender, EventArgs e)  // Ce bouton permet d'afficher le formulaire du support client et proceder aux demandes
		{
			try{
			this.Hide();
			var SupportClient = new SupportClient();
			SupportClient.ShowDialog();
			SupportClient = null;
			this.Show();
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_manuelClick(object sender, EventArgs e) // Ce bouton permet d'afficher le formulaire qui renvoi vers les manuel d'utilisation des deux applications
		{
			try{
			this.Hide();
			var Manuel = new Manuel();
			Manuel.ShowDialog();
			Manuel = null;
			this.Show();
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
	}
}
