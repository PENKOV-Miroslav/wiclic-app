﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 11:57
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using MySql.Data.MySqlClient;

namespace ApplicationWiclic_bêta_6._.__Admin
{
	/// <summary>
	/// Description of Utilisateur.
	/// </summary>
	public class Utilisateur
	{
			// Attributs privé qui seront accéssible via les methodes et constructeur public,cela permet de faire l'encapsulation et donc d'assurer la protection des informations saisit
			private int num;
			private String nomFamille;
	 		private String prenom;
			private String addresseMail;
			private String abonnement;
			private String telephone;
			private String texte;


			//constructeur	
			public Utilisateur( ) {}
			public Utilisateur( int num, String nomFamille, String prenom, String addresseMail,String abonnement,String telephone,String texte)
			{
				this.num=num;
				this.nomFamille=nomFamille;
	 			this.prenom=prenom;
	 			this.addresseMail=addresseMail;
	 			this.abonnement=abonnement;
	 			this.telephone=telephone;
	 			this.texte=texte;

		}
		//setter
		public void setnum(int num){
			this.num=num;
		}
		public void setnomFamille(String nomFamille){
			this.nomFamille=nomFamille;
		}
		public void setprenom(String prenom){
			this.prenom=prenom;
		}
		public void setaddresseMail(String addresseMail){
			this.addresseMail=addresseMail;
		}
		public void setabonnement(String abonnement){
			this.abonnement=abonnement;
		}
		public void setelephone(String telephone){
			this.telephone=telephone;
		}
		public void settexte(String texte){
			this.texte=texte;
		}

		//getter
		public String getnum(){
			return this.num.ToString();
		}
		public String getnomFamille(){
		return this.nomFamille;
		}
		public String getprenom(){
		return this.prenom;
		}
		public String getaddresseMail(){
		return this.addresseMail;
		}
		public String getabonnement(){
		return this.abonnement;
		}
		public String gettelephone(){
		return this.telephone;
		}
		public String gettexte(){
		return this.texte;
		}
		
	//méhode de création
	public void create( ) {
	 // Connexion à la base de données
	 BDD.connexion(); // appele de la classe BDD et de la methode connexion
	 String req = "INSERT INTO client (nom_de_famille, prenom, adresse_mail, abonnement) VALUES ('"+this.nomFamille+"','"+this.prenom+"','"+this.addresseMail+"','"+this.abonnement+"')"; //declaration de la requete SQL qui sera utiliser pour la création
	 MySqlCommand cmd = new MySqlCommand(req, BDD.maconnexion); //execution de la requete et de la connexion 
	 cmd.ExecuteNonQuery( );
	 
	}
	//méhode de mise à jour
	public void update() {
	 // Connexion à la base de données
	 BDD.connexion();
	 String req = "UPDATE client SET nom_de_famille = '"+this.nomFamille+"',  prenom = '"+this.prenom+"', adresse_mail = '"+this.addresseMail+"', abonnement = '"+this.abonnement+"'  WHERE num = '"+this.num+"' "; //declaration de la requete SQL qui sera utiliser pour la mise à jour
	 MySqlCommand cmd = new MySqlCommand(req, BDD.maconnexion);
	 cmd.ExecuteNonQuery( );
	}

	 //méhode de suppression
		public void delete() {
	 // Connexion à la base de données
	 BDD.connexion();
	 String req = "DELETE FROM client WHERE num='"+this.num+"'"; //declaration de la requete SQL qui sera utiliser pour la suppression
	 MySqlCommand cmd = new MySqlCommand(req, BDD.maconnexion);//execution de la commande
	 cmd.ExecuteNonQuery( );
	 
	}
	 
	 	 //méhode de suppression de la demande client
		public void deleteDemandeClient() {
	 // Connexion à la base de données
	 BDD.connexion();
	 String req = "DELETE FROM nouscontacter WHERE num='"+this.num+"'"; //declaration de la requete SQL qui sera utiliser pour la suppression
	 MySqlCommand cmd = new MySqlCommand(req, BDD.maconnexion);//execution de la commande
	 cmd.ExecuteNonQuery( );
	 
	}

			}
	 
	}
