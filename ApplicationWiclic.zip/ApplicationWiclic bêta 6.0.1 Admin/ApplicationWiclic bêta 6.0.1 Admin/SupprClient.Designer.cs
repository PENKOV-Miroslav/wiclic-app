﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 12:02
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic_bêta_6._.__Admin
{
	partial class SupprClient
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button bouton_annuler;
		private System.Windows.Forms.Button bouton_ChercheCli;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.Button bouton_Suppr;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.TextBox textBox_Recherche;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SupprClient));
			this.bouton_annuler = new System.Windows.Forms.Button();
			this.bouton_ChercheCli = new System.Windows.Forms.Button();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox_Recherche = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.bouton_Suppr = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.listView1 = new System.Windows.Forms.ListView();
			this.SuspendLayout();
			// 
			// bouton_annuler
			// 
			this.bouton_annuler.BackColor = System.Drawing.Color.LightBlue;
			this.bouton_annuler.Location = new System.Drawing.Point(891, 258);
			this.bouton_annuler.Margin = new System.Windows.Forms.Padding(11, 10, 11, 10);
			this.bouton_annuler.Name = "bouton_annuler";
			this.bouton_annuler.Size = new System.Drawing.Size(229, 59);
			this.bouton_annuler.TabIndex = 32;
			this.bouton_annuler.Text = "ANNULER";
			this.bouton_annuler.UseVisualStyleBackColor = false;
			this.bouton_annuler.Click += new System.EventHandler(this.Bouton_annulerClick);
			// 
			// bouton_ChercheCli
			// 
			this.bouton_ChercheCli.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_ChercheCli.Location = new System.Drawing.Point(891, 162);
			this.bouton_ChercheCli.Margin = new System.Windows.Forms.Padding(11, 10, 11, 10);
			this.bouton_ChercheCli.Name = "bouton_ChercheCli";
			this.bouton_ChercheCli.Size = new System.Drawing.Size(229, 77);
			this.bouton_ChercheCli.TabIndex = 31;
			this.bouton_ChercheCli.Text = "Cherche le  Client a Supprimer";
			this.bouton_ChercheCli.UseVisualStyleBackColor = false;
			this.bouton_ChercheCli.Click += new System.EventHandler(this.Bouton_ChercheCliClick);
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(514, 258);
			this.textBox2.Margin = new System.Windows.Forms.Padding(11, 10, 11, 10);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(355, 31);
			this.textBox2.TabIndex = 29;
			// 
			// textBox_Recherche
			// 
			this.textBox_Recherche.Location = new System.Drawing.Point(514, 162);
			this.textBox_Recherche.Margin = new System.Windows.Forms.Padding(11, 10, 11, 10);
			this.textBox_Recherche.Name = "textBox_Recherche";
			this.textBox_Recherche.Size = new System.Drawing.Size(355, 31);
			this.textBox_Recherche.TabIndex = 28;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(386, 258);
			this.label3.Margin = new System.Windows.Forms.Padding(11, 0, 11, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(108, 32);
			this.label3.TabIndex = 25;
			this.label3.Text = "Prenom";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(312, 162);
			this.label2.Margin = new System.Windows.Forms.Padding(11, 0, 11, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(182, 32);
			this.label2.TabIndex = 24;
			this.label2.Text = "Nom de Famille";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(609, 9);
			this.label1.Margin = new System.Windows.Forms.Padding(17, 0, 17, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(227, 37);
			this.label1.TabIndex = 23;
			this.label1.Text = "Supprimer un Client ";
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(514, 81);
			this.textBox3.Margin = new System.Windows.Forms.Padding(11, 10, 11, 10);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(355, 31);
			this.textBox3.TabIndex = 33;
			// 
			// bouton_Suppr
			// 
			this.bouton_Suppr.BackColor = System.Drawing.Color.Red;
			this.bouton_Suppr.Location = new System.Drawing.Point(891, 81);
			this.bouton_Suppr.Margin = new System.Windows.Forms.Padding(11, 10, 11, 10);
			this.bouton_Suppr.Name = "bouton_Suppr";
			this.bouton_Suppr.Size = new System.Drawing.Size(229, 59);
			this.bouton_Suppr.TabIndex = 34;
			this.bouton_Suppr.Text = "Supprimer client";
			this.bouton_Suppr.UseVisualStyleBackColor = false;
			this.bouton_Suppr.Click += new System.EventHandler(this.Bouton_SupprClick);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(390, 81);
			this.label4.Margin = new System.Windows.Forms.Padding(11, 0, 11, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(104, 41);
			this.label4.TabIndex = 35;
			this.label4.Text = "ID Client";
			// 
			// listView1
			// 
			this.listView1.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.listView1.FullRowSelect = true;
			this.listView1.Location = new System.Drawing.Point(12, 330);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(1462, 398);
			this.listView1.TabIndex = 36;
			this.listView1.UseCompatibleStateImageBehavior = false;
			// 
			// SupprClient
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumAquamarine;
			this.ClientSize = new System.Drawing.Size(1486, 756);
			this.Controls.Add(this.listView1);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.bouton_Suppr);
			this.Controls.Add(this.textBox3);
			this.Controls.Add(this.bouton_annuler);
			this.Controls.Add(this.bouton_ChercheCli);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox_Recherche);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ForeColor = System.Drawing.SystemColors.Window;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
			this.MaximumSize = new System.Drawing.Size(1502, 795);
			this.MinimumSize = new System.Drawing.Size(1502, 795);
			this.Name = "SupprClient";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "SupprClient";
			this.Load += new System.EventHandler(this.SupprClientLoad);
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
