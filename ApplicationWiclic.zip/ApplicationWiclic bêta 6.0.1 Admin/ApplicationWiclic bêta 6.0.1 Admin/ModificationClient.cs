﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 12:01
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ApplicationWiclic_bêta_6._.__Admin
{
	/// <summary>
	/// Description of ModificationClient.
	/// </summary>
	public partial class ModificationClient : Form
	{
		public ModificationClient()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		Utilisateur ApplicationWiclic = new Utilisateur(); //instanciation du nouvelle objet ApplicationWiclic via la classe Utilisateur
		
		void Bouton_ModifierClick(object sender, EventArgs e)
		{
			try{ //essaye d'executer les commande suivante et si echeque affiche un message d'erreur via le catch
		    ApplicationWiclic.setnomFamille( textBox1.Text);
			ApplicationWiclic.setprenom( textBox2.Text);
			ApplicationWiclic.setaddresseMail( textBox3.Text);
			ApplicationWiclic.setabonnement( comboBox1.Text);
			ApplicationWiclic.setnum (int.Parse( textBox4.Text));
			BDD.connexion(); //appele la methode de connexion
			ApplicationWiclic.update();  //appele la methode de modification du client
			textBox1.Text=String.Empty;  //efface le contenu des textBox
			textBox2.Text=String.Empty;
			textBox3.Text=String.Empty;
			comboBox1.Text=String.Empty;
			textBox4.Text=String.Empty;
			MessageBox.Show("Le client a été modifié");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_annulerClick(object sender, EventArgs e)	 // Bouton qui permet la fermeture de la fenetre
		{
			this.Close();
		}
		void Bouton_rechercheCliClick(object sender, EventArgs e)
		{
			try{
			string nom = textBox5.Text;
			string fichier = System.IO.File.ReadAllText ("connexHostIP.ini");
			string con = "data source="+fichier+"; initial catalog=wiclic;user id=root;password=;";
			MySqlConnection cnn = new MySqlConnection(con);
			cnn.Open();
			string sql = "SELECT* FROM client WHERE nom_de_famille LIKE '%"+nom+"%'";
			MySqlCommand cmd = new MySqlCommand(sql,cnn);
			MySqlDataReader rd;
			rd = cmd.ExecuteReader();
			listView1.Items.Clear();
			while (rd.Read())
			{
				ListViewItem lv = new ListViewItem();
				lv.SubItems.Add(rd.GetInt32(0).ToString());
				lv.SubItems.Add(rd.GetString(1).ToString());
				lv.SubItems.Add(rd.GetString(2).ToString());
				lv.SubItems.Add(rd.GetString(3).ToString());
				lv.SubItems.Add(rd.GetString(4).ToString());

				listView1.Items.Add(lv);
			}
			
			rd.Close();
			cmd.Dispose();
			cnn.Close();
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void ModificationClientLoad(object sender, EventArgs e)
		{
			listView1.GridLines = true;
			listView1.View = View.Details;
			listView1.Columns.Add("",0);
			listView1.Columns.Add("ID Client",150);
			listView1.Columns.Add("Nom de Famille",250);
			listView1.Columns.Add("Prenom",150);
			listView1.Columns.Add("E-Mail",300);
			listView1.Columns.Add(" Est Abonné ?",350);

		}
	}
}
