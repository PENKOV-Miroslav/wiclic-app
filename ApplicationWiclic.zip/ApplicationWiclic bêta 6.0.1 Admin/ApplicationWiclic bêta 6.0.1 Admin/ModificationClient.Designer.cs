﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 12:01
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic_bêta_6._.__Admin
{
	partial class ModificationClient
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Button bouton_annuler;
		private System.Windows.Forms.Button bouton_Modifier;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button bouton_rechercheCli;
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.TextBox textBox5;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModificationClient));
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.bouton_annuler = new System.Windows.Forms.Button();
			this.bouton_Modifier = new System.Windows.Forms.Button();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.bouton_rechercheCli = new System.Windows.Forms.Button();
			this.listView1 = new System.Windows.Forms.ListView();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// comboBox1
			// 
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
			"OUI",
			"NON"});
			this.comboBox1.Location = new System.Drawing.Point(357, 408);
			this.comboBox1.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(293, 39);
			this.comboBox1.TabIndex = 22;
			// 
			// bouton_annuler
			// 
			this.bouton_annuler.BackColor = System.Drawing.Color.LightBlue;
			this.bouton_annuler.Location = new System.Drawing.Point(754, 250);
			this.bouton_annuler.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.bouton_annuler.Name = "bouton_annuler";
			this.bouton_annuler.Size = new System.Drawing.Size(248, 83);
			this.bouton_annuler.TabIndex = 21;
			this.bouton_annuler.Text = "ANNULER";
			this.bouton_annuler.UseVisualStyleBackColor = false;
			this.bouton_annuler.Click += new System.EventHandler(this.Bouton_annulerClick);
			// 
			// bouton_Modifier
			// 
			this.bouton_Modifier.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_Modifier.Location = new System.Drawing.Point(754, 128);
			this.bouton_Modifier.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.bouton_Modifier.Name = "bouton_Modifier";
			this.bouton_Modifier.Size = new System.Drawing.Size(248, 106);
			this.bouton_Modifier.TabIndex = 20;
			this.bouton_Modifier.Text = "Appliquer les modifications Client";
			this.bouton_Modifier.UseVisualStyleBackColor = false;
			this.bouton_Modifier.Click += new System.EventHandler(this.Bouton_ModifierClick);
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(357, 332);
			this.textBox3.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(293, 38);
			this.textBox3.TabIndex = 19;
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(357, 256);
			this.textBox2.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(293, 38);
			this.textBox2.TabIndex = 18;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(357, 178);
			this.textBox1.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(293, 38);
			this.textBox1.TabIndex = 17;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(126, 408);
			this.label5.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(214, 62);
			this.label5.TabIndex = 16;
			this.label5.Text = "Abonnement";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(196, 332);
			this.label4.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(145, 62);
			this.label4.TabIndex = 15;
			this.label4.Text = "E-mail";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(196, 256);
			this.label3.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(145, 62);
			this.label3.TabIndex = 14;
			this.label3.Text = "Prenom";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(99, 178);
			this.label2.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(241, 62);
			this.label2.TabIndex = 13;
			this.label2.Text = "Nom de Famille";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(357, 9);
			this.label1.Margin = new System.Windows.Forms.Padding(14, 0, 14, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(477, 84);
			this.label1.TabIndex = 12;
			this.label1.Text = "Modification du Client dans la BDD";
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(357, 101);
			this.textBox4.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(293, 38);
			this.textBox4.TabIndex = 23;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(100, 101);
			this.label6.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(241, 62);
			this.label6.TabIndex = 24;
			this.label6.Text = "ID Client";
			// 
			// bouton_rechercheCli
			// 
			this.bouton_rechercheCli.BackColor = System.Drawing.Color.Khaki;
			this.bouton_rechercheCli.Location = new System.Drawing.Point(895, 440);
			this.bouton_rechercheCli.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.bouton_rechercheCli.Name = "bouton_rechercheCli";
			this.bouton_rechercheCli.Size = new System.Drawing.Size(244, 81);
			this.bouton_rechercheCli.TabIndex = 25;
			this.bouton_rechercheCli.Text = "Recherche Client pour Modif";
			this.bouton_rechercheCli.UseVisualStyleBackColor = false;
			this.bouton_rechercheCli.Click += new System.EventHandler(this.Bouton_rechercheCliClick);
			// 
			// listView1
			// 
			this.listView1.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.listView1.FullRowSelect = true;
			this.listView1.Location = new System.Drawing.Point(12, 532);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(1127, 158);
			this.listView1.TabIndex = 26;
			this.listView1.UseCompatibleStateImageBehavior = false;
			// 
			// textBox5
			// 
			this.textBox5.Location = new System.Drawing.Point(599, 483);
			this.textBox5.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(293, 38);
			this.textBox5.TabIndex = 27;
			// 
			// ModificationClient
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 31F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumAquamarine;
			this.ClientSize = new System.Drawing.Size(1157, 714);
			this.Controls.Add(this.textBox5);
			this.Controls.Add(this.listView1);
			this.Controls.Add(this.bouton_rechercheCli);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.textBox4);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.bouton_annuler);
			this.Controls.Add(this.bouton_Modifier);
			this.Controls.Add(this.textBox3);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ForeColor = System.Drawing.SystemColors.Window;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
			this.MaximumSize = new System.Drawing.Size(1173, 753);
			this.MinimumSize = new System.Drawing.Size(1173, 753);
			this.Name = "ModificationClient";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "ModificationClient";
			this.Load += new System.EventHandler(this.ModificationClientLoad);
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
