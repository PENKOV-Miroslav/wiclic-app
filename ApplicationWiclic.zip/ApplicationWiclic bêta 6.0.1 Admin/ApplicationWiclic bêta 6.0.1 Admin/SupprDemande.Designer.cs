﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 28/06/2022
 * Heure: 14:48
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic_bêta_6._.__Admin
{
	partial class SupprDemande
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button bouton_SupprDemande;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox textBox1;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SupprDemande));
			this.bouton_SupprDemande = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// bouton_SupprDemande
			// 
			this.bouton_SupprDemande.BackColor = System.Drawing.Color.PaleGreen;
			this.bouton_SupprDemande.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_SupprDemande.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_SupprDemande.Location = new System.Drawing.Point(428, 12);
			this.bouton_SupprDemande.Name = "bouton_SupprDemande";
			this.bouton_SupprDemande.Size = new System.Drawing.Size(148, 86);
			this.bouton_SupprDemande.TabIndex = 0;
			this.bouton_SupprDemande.Text = "Supprimer la demande";
			this.bouton_SupprDemande.UseVisualStyleBackColor = false;
			this.bouton_SupprDemande.Click += new System.EventHandler(this.Bouton_SupprDemandeClick);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.textBox1);
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox1.Location = new System.Drawing.Point(28, 12);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(336, 87);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Entrer ID Demande ci-dessous :";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(6, 25);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(315, 55);
			this.textBox1.TabIndex = 3;
			// 
			// SupprDemande
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumAquamarine;
			this.ClientSize = new System.Drawing.Size(607, 110);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.bouton_SupprDemande);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximumSize = new System.Drawing.Size(623, 149);
			this.MinimumSize = new System.Drawing.Size(623, 149);
			this.Name = "SupprDemande";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "SupprDemande";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.ResumeLayout(false);

		}
	}
}
