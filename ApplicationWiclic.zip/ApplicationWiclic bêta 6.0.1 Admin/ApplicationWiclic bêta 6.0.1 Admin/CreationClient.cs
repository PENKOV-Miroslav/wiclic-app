﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 12:00
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace ApplicationWiclic_bêta_6._.__Admin
{
	/// <summary>
	/// Description of CreationClient.
	/// </summary>
	public partial class CreationClient : Form
	{
		public CreationClient()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		Utilisateur ApplicationWiclic = new Utilisateur();	//instanciation du nouvelle objet ApplicationWiclic via la classe Utilisateur
		
		void Bouton_CreationClick(object sender, EventArgs e)
		{
			try{ 

				//essaye d'executer les commande suivante et si echeque affiche un message d'erreur via le catch
			ApplicationWiclic.setnomFamille( textBox1.Text);
			ApplicationWiclic.setprenom( textBox2.Text);
			ApplicationWiclic.setaddresseMail( textBox3.Text);
			ApplicationWiclic.setabonnement( comboBox1.Text);
		 const string strRegexMail = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" + @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" + @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"; //pattern qui verifie l'e-mail sui la synthaxe est correcte avec un bon nom de domaine
		 Regex RegexMail = new Regex(strRegexMail);

		 if( RegexMail.IsMatch(ApplicationWiclic.getaddresseMail())) {
			BDD.connexion(); //appele la methode de connexion
			ApplicationWiclic.create(); //appele la methode de creation du client
			textBox1.Text=String.Empty; //efface le contenu des textBox
			textBox2.Text=String.Empty;
			textBox3.Text=String.Empty;
			comboBox1.Text=String.Empty;
			MessageBox.Show("Le client est créé"); //message avertissant de la création
			}
		 else 
		 {
		 	 MessageBox.Show("Saisir une adresse mail valide");
		 }
		}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		
		void Bouton_annulerClick(object sender, EventArgs e)  // Bouton qui permet la fermeture de la fenetre
		{
			this.Close();
		}


	}
}
