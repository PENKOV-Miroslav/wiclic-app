﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 12:06
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic_bêta_6._.__Admin
{
	partial class SupportClient
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button bouton_supprDemande;
		private System.Windows.Forms.Button bouton_RechargePage;
		private System.Windows.Forms.ListView listView1;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SupportClient));
			this.bouton_supprDemande = new System.Windows.Forms.Button();
			this.bouton_RechargePage = new System.Windows.Forms.Button();
			this.listView1 = new System.Windows.Forms.ListView();
			this.SuspendLayout();
			// 
			// bouton_supprDemande
			// 
			this.bouton_supprDemande.Location = new System.Drawing.Point(203, 45);
			this.bouton_supprDemande.Name = "bouton_supprDemande";
			this.bouton_supprDemande.Size = new System.Drawing.Size(173, 119);
			this.bouton_supprDemande.TabIndex = 1;
			this.bouton_supprDemande.Text = "Supprimer La Demande";
			this.bouton_supprDemande.UseVisualStyleBackColor = true;
			this.bouton_supprDemande.Click += new System.EventHandler(this.Bouton_supprDemandeClick);
			// 
			// bouton_RechargePage
			// 
			this.bouton_RechargePage.Location = new System.Drawing.Point(12, 45);
			this.bouton_RechargePage.Name = "bouton_RechargePage";
			this.bouton_RechargePage.Size = new System.Drawing.Size(185, 119);
			this.bouton_RechargePage.TabIndex = 2;
			this.bouton_RechargePage.Text = "Recharger les Demande";
			this.bouton_RechargePage.UseVisualStyleBackColor = true;
			this.bouton_RechargePage.Click += new System.EventHandler(this.Bouton_RechargePageClick);
			// 
			// listView1
			// 
			this.listView1.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.listView1.FullRowSelect = true;
			this.listView1.Location = new System.Drawing.Point(12, 185);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(961, 415);
			this.listView1.TabIndex = 3;
			this.listView1.UseCompatibleStateImageBehavior = false;
			// 
			// SupportClient
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 31F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumAquamarine;
			this.ClientSize = new System.Drawing.Size(990, 622);
			this.Controls.Add(this.listView1);
			this.Controls.Add(this.bouton_RechargePage);
			this.Controls.Add(this.bouton_supprDemande);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
			this.MaximumSize = new System.Drawing.Size(1006, 661);
			this.MinimumSize = new System.Drawing.Size(1006, 661);
			this.Name = "SupportClient";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "SupportClient";
			this.Load += new System.EventHandler(this.SupportClientLoad);
			this.ResumeLayout(false);

		}
	}
}
