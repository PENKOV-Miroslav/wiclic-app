﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 11:33
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic_bêta_6._.__Admin
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button bouton_création;
		private System.Windows.Forms.Button bouton_modifCli;
		private System.Windows.Forms.Button bouton_rechCli;
		private System.Windows.Forms.Button bouton_supprCli;
		private System.Windows.Forms.Button bouton_support;
		private System.Windows.Forms.Button bouton_manuel;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.label1 = new System.Windows.Forms.Label();
			this.bouton_création = new System.Windows.Forms.Button();
			this.bouton_modifCli = new System.Windows.Forms.Button();
			this.bouton_rechCli = new System.Windows.Forms.Button();
			this.bouton_supprCli = new System.Windows.Forms.Button();
			this.bouton_support = new System.Windows.Forms.Button();
			this.bouton_manuel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(341, 24);
			this.label1.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(276, 35);
			this.label1.TabIndex = 0;
			this.label1.Text = "Wiclic Center Admin";
			// 
			// bouton_création
			// 
			this.bouton_création.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_création.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_création.Image = ((System.Drawing.Image)(resources.GetObject("bouton_création.Image")));
			this.bouton_création.Location = new System.Drawing.Point(56, 99);
			this.bouton_création.Margin = new System.Windows.Forms.Padding(5);
			this.bouton_création.Name = "bouton_création";
			this.bouton_création.Size = new System.Drawing.Size(276, 146);
			this.bouton_création.TabIndex = 1;
			this.bouton_création.Text = "Creation Client";
			this.bouton_création.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_création.UseVisualStyleBackColor = true;
			this.bouton_création.Click += new System.EventHandler(this.Bouton_créationClick);
			// 
			// bouton_modifCli
			// 
			this.bouton_modifCli.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_modifCli.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_modifCli.Image = ((System.Drawing.Image)(resources.GetObject("bouton_modifCli.Image")));
			this.bouton_modifCli.Location = new System.Drawing.Point(341, 99);
			this.bouton_modifCli.Margin = new System.Windows.Forms.Padding(5);
			this.bouton_modifCli.Name = "bouton_modifCli";
			this.bouton_modifCli.Size = new System.Drawing.Size(276, 146);
			this.bouton_modifCli.TabIndex = 2;
			this.bouton_modifCli.Text = "Modification Client";
			this.bouton_modifCli.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_modifCli.UseVisualStyleBackColor = true;
			this.bouton_modifCli.Click += new System.EventHandler(this.Bouton_modifCliClick);
			// 
			// bouton_rechCli
			// 
			this.bouton_rechCli.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_rechCli.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_rechCli.Image = ((System.Drawing.Image)(resources.GetObject("bouton_rechCli.Image")));
			this.bouton_rechCli.Location = new System.Drawing.Point(56, 254);
			this.bouton_rechCli.Margin = new System.Windows.Forms.Padding(5);
			this.bouton_rechCli.Name = "bouton_rechCli";
			this.bouton_rechCli.Size = new System.Drawing.Size(276, 146);
			this.bouton_rechCli.TabIndex = 3;
			this.bouton_rechCli.Text = "Recherche Client";
			this.bouton_rechCli.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_rechCli.UseVisualStyleBackColor = true;
			this.bouton_rechCli.Click += new System.EventHandler(this.Bouton_rechCliClick);
			// 
			// bouton_supprCli
			// 
			this.bouton_supprCli.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_supprCli.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_supprCli.Image = ((System.Drawing.Image)(resources.GetObject("bouton_supprCli.Image")));
			this.bouton_supprCli.Location = new System.Drawing.Point(341, 254);
			this.bouton_supprCli.Margin = new System.Windows.Forms.Padding(5);
			this.bouton_supprCli.Name = "bouton_supprCli";
			this.bouton_supprCli.Size = new System.Drawing.Size(276, 146);
			this.bouton_supprCli.TabIndex = 4;
			this.bouton_supprCli.Text = "Supprimer Client";
			this.bouton_supprCli.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_supprCli.UseVisualStyleBackColor = true;
			this.bouton_supprCli.Click += new System.EventHandler(this.Bouton_supprCliClick);
			// 
			// bouton_support
			// 
			this.bouton_support.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_support.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_support.Image = ((System.Drawing.Image)(resources.GetObject("bouton_support.Image")));
			this.bouton_support.Location = new System.Drawing.Point(628, 99);
			this.bouton_support.Margin = new System.Windows.Forms.Padding(5);
			this.bouton_support.Name = "bouton_support";
			this.bouton_support.Size = new System.Drawing.Size(276, 146);
			this.bouton_support.TabIndex = 8;
			this.bouton_support.Text = "Voir les tickets de support";
			this.bouton_support.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_support.UseVisualStyleBackColor = true;
			this.bouton_support.Click += new System.EventHandler(this.Bouton_supportClick);
			// 
			// bouton_manuel
			// 
			this.bouton_manuel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_manuel.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_manuel.Image = ((System.Drawing.Image)(resources.GetObject("bouton_manuel.Image")));
			this.bouton_manuel.Location = new System.Drawing.Point(628, 254);
			this.bouton_manuel.Margin = new System.Windows.Forms.Padding(5);
			this.bouton_manuel.Name = "bouton_manuel";
			this.bouton_manuel.Size = new System.Drawing.Size(276, 146);
			this.bouton_manuel.TabIndex = 9;
			this.bouton_manuel.Text = "Voir le Manuel d\'utilisation";
			this.bouton_manuel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_manuel.UseVisualStyleBackColor = true;
			this.bouton_manuel.Click += new System.EventHandler(this.Bouton_manuelClick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 31F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumAquamarine;
			this.ClientSize = new System.Drawing.Size(973, 456);
			this.Controls.Add(this.bouton_manuel);
			this.Controls.Add(this.bouton_support);
			this.Controls.Add(this.bouton_supprCli);
			this.Controls.Add(this.bouton_rechCli);
			this.Controls.Add(this.bouton_modifCli);
			this.Controls.Add(this.bouton_création);
			this.Controls.Add(this.label1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ForeColor = System.Drawing.SystemColors.Window;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
			this.MaximumSize = new System.Drawing.Size(989, 495);
			this.MinimumSize = new System.Drawing.Size(989, 495);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Application Wiclic Admin";
			this.ResumeLayout(false);

		}
	}
}
