﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 24/06/2022
 * Heure: 09:10
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Windows.Forms;

namespace ApplicationWiclic
{
	/// <summary>
	/// Description of SiteWebBank.
	/// </summary>
	public partial class SiteWebBank : Form
	{
		public SiteWebBank()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void LinkLabel_wikiLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.orangebank.fr/");
		}
		void LinkLabel_frconnectLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.labanquepostale.fr/");
		}
		void LinkLabel_BfBLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.bforbank.com/");
		}
		void LinkLabel_helloBQLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.hellobank.fr/");
		}
		void LinkLabel_BoursoramaLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.boursorama.com/");
		}
		void LinkLabel_LCLLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.lcl.fr/");
		}
		void LinkLabel_CICLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.cic.fr/fr/index.html");
		}
	}
}
