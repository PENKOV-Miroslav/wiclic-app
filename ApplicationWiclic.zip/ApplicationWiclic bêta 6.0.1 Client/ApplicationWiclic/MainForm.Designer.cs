﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 13/06/2022
 * Heure: 09:56
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button bouton_support;
		private System.Windows.Forms.Button bouton_siteWeb;
		private System.Windows.Forms.Button bouton_actu;
		private System.Windows.Forms.Button bouton_teleassistance;
		private System.Windows.Forms.Button bouton_controle;
		private System.Windows.Forms.Button bouton_siteRecommander;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button bouton_wiclicApps;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.bouton_siteRecommander = new System.Windows.Forms.Button();
			this.bouton_actu = new System.Windows.Forms.Button();
			this.bouton_support = new System.Windows.Forms.Button();
			this.bouton_siteWeb = new System.Windows.Forms.Button();
			this.bouton_teleassistance = new System.Windows.Forms.Button();
			this.bouton_controle = new System.Windows.Forms.Button();
			this.bouton_wiclicApps = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.BackColor = System.Drawing.Color.MediumAquamarine;
			this.groupBox1.Controls.Add(this.tableLayoutPanel1);
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox1.ForeColor = System.Drawing.SystemColors.Window;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox1.MinimumSize = new System.Drawing.Size(867, 760);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox1.Size = new System.Drawing.Size(867, 760);
			this.groupBox1.TabIndex = 21;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Les outils mis à votre disposition";
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.MediumAquamarine;
			this.tableLayoutPanel1.ColumnCount = 3;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.53874F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.49225F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.96901F));
			this.tableLayoutPanel1.Controls.Add(this.bouton_siteRecommander, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.bouton_actu, 2, 0);
			this.tableLayoutPanel1.Controls.Add(this.bouton_support, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.bouton_siteWeb, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.bouton_teleassistance, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.bouton_controle, 2, 1);
			this.tableLayoutPanel1.Controls.Add(this.bouton_wiclicApps, 0, 2);
			this.tableLayoutPanel1.Location = new System.Drawing.Point(11, 38);
			this.tableLayoutPanel1.MinimumSize = new System.Drawing.Size(845, 703);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 3;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.59459F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.41441F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.83333F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(845, 703);
			this.tableLayoutPanel1.TabIndex = 24;
			// 
			// bouton_siteRecommander
			// 
			this.bouton_siteRecommander.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_siteRecommander.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.bouton_siteRecommander.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_siteRecommander.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_siteRecommander.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_siteRecommander.Image = ((System.Drawing.Image)(resources.GetObject("bouton_siteRecommander.Image")));
			this.bouton_siteRecommander.Location = new System.Drawing.Point(4, 248);
			this.bouton_siteRecommander.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.bouton_siteRecommander.MinimumSize = new System.Drawing.Size(266, 232);
			this.bouton_siteRecommander.Name = "bouton_siteRecommander";
			this.bouton_siteRecommander.Size = new System.Drawing.Size(266, 232);
			this.bouton_siteRecommander.TabIndex = 6;
			this.bouton_siteRecommander.Text = "4 - SITES SÛRS";
			this.bouton_siteRecommander.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_siteRecommander.UseVisualStyleBackColor = false;
			this.bouton_siteRecommander.Click += new System.EventHandler(this.Bouton_siteRecommanderClick);
			// 
			// bouton_actu
			// 
			this.bouton_actu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_actu.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.bouton_actu.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_actu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_actu.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_actu.Image = ((System.Drawing.Image)(resources.GetObject("bouton_actu.Image")));
			this.bouton_actu.Location = new System.Drawing.Point(561, 5);
			this.bouton_actu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.bouton_actu.MinimumSize = new System.Drawing.Size(280, 233);
			this.bouton_actu.Name = "bouton_actu";
			this.bouton_actu.Size = new System.Drawing.Size(280, 233);
			this.bouton_actu.TabIndex = 4;
			this.bouton_actu.Text = "3 - ACTUALITES";
			this.bouton_actu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_actu.UseVisualStyleBackColor = false;
			this.bouton_actu.Click += new System.EventHandler(this.Bouton_actuClick);
			// 
			// bouton_support
			// 
			this.bouton_support.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_support.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.bouton_support.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_support.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_support.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_support.Image = ((System.Drawing.Image)(resources.GetObject("bouton_support.Image")));
			this.bouton_support.Location = new System.Drawing.Point(4, 5);
			this.bouton_support.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.bouton_support.MinimumSize = new System.Drawing.Size(266, 233);
			this.bouton_support.Name = "bouton_support";
			this.bouton_support.Size = new System.Drawing.Size(266, 233);
			this.bouton_support.TabIndex = 1;
			this.bouton_support.Text = "1 - SUPPORT";
			this.bouton_support.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_support.UseVisualStyleBackColor = false;
			this.bouton_support.Click += new System.EventHandler(this.Bouton_supportClick);
			// 
			// bouton_siteWeb
			// 
			this.bouton_siteWeb.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_siteWeb.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.bouton_siteWeb.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_siteWeb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_siteWeb.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_siteWeb.Image = ((System.Drawing.Image)(resources.GetObject("bouton_siteWeb.Image")));
			this.bouton_siteWeb.Location = new System.Drawing.Point(278, 5);
			this.bouton_siteWeb.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.bouton_siteWeb.MinimumSize = new System.Drawing.Size(275, 233);
			this.bouton_siteWeb.Name = "bouton_siteWeb";
			this.bouton_siteWeb.Size = new System.Drawing.Size(275, 233);
			this.bouton_siteWeb.TabIndex = 2;
			this.bouton_siteWeb.Text = "2 - SITE WEB WICLIC";
			this.bouton_siteWeb.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_siteWeb.UseVisualStyleBackColor = false;
			this.bouton_siteWeb.Click += new System.EventHandler(this.Bouton_siteWebClick);
			// 
			// bouton_teleassistance
			// 
			this.bouton_teleassistance.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_teleassistance.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.bouton_teleassistance.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_teleassistance.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_teleassistance.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_teleassistance.Image = ((System.Drawing.Image)(resources.GetObject("bouton_teleassistance.Image")));
			this.bouton_teleassistance.Location = new System.Drawing.Point(278, 248);
			this.bouton_teleassistance.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.bouton_teleassistance.MinimumSize = new System.Drawing.Size(275, 232);
			this.bouton_teleassistance.Name = "bouton_teleassistance";
			this.bouton_teleassistance.Size = new System.Drawing.Size(275, 232);
			this.bouton_teleassistance.TabIndex = 7;
			this.bouton_teleassistance.Text = "5 -TELEASSISTANCE";
			this.bouton_teleassistance.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_teleassistance.UseVisualStyleBackColor = false;
			this.bouton_teleassistance.Click += new System.EventHandler(this.Bouton_teleassistanceClick);
			// 
			// bouton_controle
			// 
			this.bouton_controle.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_controle.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.bouton_controle.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_controle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_controle.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_controle.Image = ((System.Drawing.Image)(resources.GetObject("bouton_controle.Image")));
			this.bouton_controle.Location = new System.Drawing.Point(561, 248);
			this.bouton_controle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.bouton_controle.MinimumSize = new System.Drawing.Size(280, 232);
			this.bouton_controle.Name = "bouton_controle";
			this.bouton_controle.Size = new System.Drawing.Size(280, 232);
			this.bouton_controle.TabIndex = 8;
			this.bouton_controle.Text = "6 - CONTROLE PARENTAL";
			this.bouton_controle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_controle.UseVisualStyleBackColor = false;
			this.bouton_controle.Click += new System.EventHandler(this.Bouton_controleClick);
			// 
			// bouton_wiclicApps
			// 
			this.bouton_wiclicApps.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_wiclicApps.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.bouton_wiclicApps.BackColor = System.Drawing.SystemColors.Window;
			this.tableLayoutPanel1.SetColumnSpan(this.bouton_wiclicApps, 3);
			this.bouton_wiclicApps.Image = ((System.Drawing.Image)(resources.GetObject("bouton_wiclicApps.Image")));
			this.bouton_wiclicApps.Location = new System.Drawing.Point(3, 489);
			this.bouton_wiclicApps.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.bouton_wiclicApps.MinimumSize = new System.Drawing.Size(833, 167);
			this.bouton_wiclicApps.Name = "bouton_wiclicApps";
			this.bouton_wiclicApps.Size = new System.Drawing.Size(839, 210);
			this.bouton_wiclicApps.TabIndex = 23;
			this.bouton_wiclicApps.UseVisualStyleBackColor = false;
			this.bouton_wiclicApps.Click += new System.EventHandler(this.Bouton_wiclicAppsClick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(863, 760);
			this.Controls.Add(this.groupBox1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.MinimumSize = new System.Drawing.Size(879, 799);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Application Wiclic";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
