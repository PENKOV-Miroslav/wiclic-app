﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 10:32
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;

using System.Windows.Forms;
using System.Diagnostics;

namespace ApplicationWiclic
{
	/// <summary>
	/// Description of ControlParental.
	/// </summary>
	
	public partial class ControlParental : Form
	{
		public ControlParental()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//	
			
		}
		Client ApplicationWiclic = new Client();
		
		void Bouton_optionLimiteTemps1Click(object sender, EventArgs e)
		{
			Process.Start("shutdown.exe", "-s -t 3600");
			MessageBox.Show("L'ordinateur va s'eteindre dans 1 heures à compter de maintenant");
		}
		void Bouton_optionLimiteTemps2Click(object sender, EventArgs e)
		{
			Process.Start("shutdown.exe", "-s -t 7200");
			MessageBox.Show("L'ordinateur va s'eteindre dans 2 heures à compter de maintenant");
		}
		void Bouton_optionLimiteTemps3Click(object sender, EventArgs e)
		{
			Process.Start("shutdown.exe", "-s -t 10800");
			MessageBox.Show("L'ordinateur va s'eteindre dans 3 heures à compter de maintenant");
		}
		void Bouton_optionLimiteTemps4Click(object sender, EventArgs e)
		{
			Process.Start("shutdown.exe", "-s -t 14400");
			MessageBox.Show("L'ordinateur va s'eteindre dans 4 heures à compter de maintenant");
		}
		void AnnuletTempsLimiteClick(object sender, EventArgs e)
		{
			Process.Start("shutdown.exe", "-a");
			MessageBox.Show("Vous avez annulé la limite de temps, votre pc ne va pas s'éteindre");
		}
		void Bouton_optionSiteWeb1Click(object sender, EventArgs e)
		{

			try{
			 
			ApplicationWiclic.ExecuteAsAdmin("CMD.exe","/K netsh interface ipv4 add dnsserver \"Ethernet\" 208.67.222.123 index=1 validate=yes && netsh interface ipv4 add dnsserver \"Ethernet\" 208.67.220.123 index=2 validate=yes && netsh interface ipv4 add dnsserver \"Wi-Fi\" 208.67.222.123 index=1 validate=yes && netsh interface ipv4 add dnsserver \"Wi-Fi\" 208.67.220.123 index=2 validate=yes && ipconfig /flushdns && exit");
			MessageBox.Show("Vous avez activé l'option limite sites pour adulte");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_optionSiteWeb2Click(object sender, EventArgs e)
		{
			try{
			 
			ApplicationWiclic.ExecuteAsAdmin("CMD.exe","/K netsh interface ipv4 add dnsserver \"Ethernet\" 156.154.70.3 index=1 validate=yes && netsh interface ipv4 add dnsserver \"Ethernet\" 156.154.71.3 index=2 validate=yes && netsh interface ipv4 add dnsserver \"Wi-Fi\" 156.154.70.3 index=1 validate=yes && netsh interface ipv4 add dnsserver \"Wi-Fi\" 156.154.71.3 index=2 validate=yes && ipconfig /flushdns && exit");
			MessageBox.Show("Vous avez activé l'option limite sites pour adulte");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_optionSiteWeb3Click(object sender, EventArgs e)
		{
			try{
			 
			ApplicationWiclic.ExecuteAsAdmin("CMD.exe","/K netsh interface ipv4 add dnsserver \"Ethernet\" 77.88.8.7 index=1 validate=yes && netsh interface ipv4 add dnsserver \"Ethernet\" 77.88.8.3 index=2 validate=yes && netsh interface ipv4 add dnsserver \"Wi-Fi\" 77.88.8.7 index=1 validate=yes && netsh interface ipv4 add dnsserver \"Wi-Fi\" 77.88.8.3 index=2 validate=yes && ipconfig /flushdns && exit");
			MessageBox.Show("Vous avez activé l'option limite sites pour adulte");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_optionSiteWeb4Click(object sender, EventArgs e)
		{
			try{
			 
			ApplicationWiclic.ExecuteAsAdmin("CMD.exe","/K netsh interface ipv4 add dnsserver \"Ethernet\" 185.228.168.168 index=1 validate=yes && netsh interface ipv4 add dnsserver \"Ethernet\" 185.228.169.168 index=2 validate=yes && netsh interface ipv4 add dnsserver \"Wi-Fi\" 185.228.168.168 index=1 validate=yes  && netsh interface ipv4 add dnsserver \"Wi-Fi\" 185.228.169.168 index=2 validate=yes && ipconfig /flushdns && exit");
			MessageBox.Show("Vous avez activé l'option limite sites pour adulte");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void AnnuletLimiteWebClick(object sender, EventArgs e)
		{
			try{
			 
			ApplicationWiclic.ExecuteAsAdmin("CMD.exe","/K netsh interface ipv4 set dnsservers \"Ethernet\" dhcp && netsh interface ipv4 set dnsservers \"Wi-Fi\" dhcp && ipconfig /flushdns && exit ");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_desactiveToutClick(object sender, EventArgs e)
		{
			try{
			 
			ApplicationWiclic.ExecuteAsAdmin("CMD.exe","/K netsh interface ipv4 set dnsservers \"Ethernet\" dhcp && netsh interface ipv4 set dnsservers \"Wi-Fi\" dhcp && ipconfig /flushdns && exit ");
			Process.Start("shutdown.exe", "-a");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_WiclicCenterClick(object sender, EventArgs e)
		{
			this.Close();
		}



    }
}
