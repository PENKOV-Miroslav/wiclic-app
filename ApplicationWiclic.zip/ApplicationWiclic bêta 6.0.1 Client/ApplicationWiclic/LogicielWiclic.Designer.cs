﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 20/06/2022
 * Heure: 17:14
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic
{
	partial class LogicielWiclic
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.ProgressBar progressBar1;
		private System.Windows.Forms.Button bouton_pandaCloud;
		private System.Windows.Forms.Button bouton_Defrag;
		private System.Windows.Forms.Button bouton_TeamViewer;
		private System.Windows.Forms.Button bouton_adwcleaner;
		private System.Windows.Forms.Button bouton_nettoyage;
		private System.Windows.Forms.Button bouton_UAC_Active;
		private System.Windows.Forms.Button bouton_UAC_Desactive;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogicielWiclic));
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.bouton_UAC_Active = new System.Windows.Forms.Button();
			this.bouton_UAC_Desactive = new System.Windows.Forms.Button();
			this.bouton_nettoyage = new System.Windows.Forms.Button();
			this.progressBar1 = new System.Windows.Forms.ProgressBar();
			this.bouton_pandaCloud = new System.Windows.Forms.Button();
			this.bouton_Defrag = new System.Windows.Forms.Button();
			this.bouton_TeamViewer = new System.Windows.Forms.Button();
			this.bouton_adwcleaner = new System.Windows.Forms.Button();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.groupBox2.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox2
			// 
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox2.BackColor = System.Drawing.Color.MediumAquamarine;
			this.groupBox2.Controls.Add(this.tableLayoutPanel1);
			this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox2.ForeColor = System.Drawing.SystemColors.Window;
			this.groupBox2.Location = new System.Drawing.Point(0, 2);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(1002, 656);
			this.groupBox2.TabIndex = 23;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Les logiciels à télécharger";
			// 
			// bouton_UAC_Active
			// 
			this.bouton_UAC_Active.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_UAC_Active.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_UAC_Active.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_UAC_Active.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_UAC_Active.Image = ((System.Drawing.Image)(resources.GetObject("bouton_UAC_Active.Image")));
			this.bouton_UAC_Active.Location = new System.Drawing.Point(491, 343);
			this.bouton_UAC_Active.Margin = new System.Windows.Forms.Padding(4);
			this.bouton_UAC_Active.Name = "bouton_UAC_Active";
			this.bouton_UAC_Active.Size = new System.Drawing.Size(236, 266);
			this.bouton_UAC_Active.TabIndex = 22;
			this.bouton_UAC_Active.Text = "Active UAC";
			this.bouton_UAC_Active.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_UAC_Active.UseVisualStyleBackColor = false;
			this.bouton_UAC_Active.Click += new System.EventHandler(this.Bouton_UAC_ActiveClick);
			// 
			// bouton_UAC_Desactive
			// 
			this.bouton_UAC_Desactive.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_UAC_Desactive.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_UAC_Desactive.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_UAC_Desactive.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_UAC_Desactive.Image = ((System.Drawing.Image)(resources.GetObject("bouton_UAC_Desactive.Image")));
			this.bouton_UAC_Desactive.Location = new System.Drawing.Point(248, 343);
			this.bouton_UAC_Desactive.Margin = new System.Windows.Forms.Padding(4);
			this.bouton_UAC_Desactive.Name = "bouton_UAC_Desactive";
			this.bouton_UAC_Desactive.Size = new System.Drawing.Size(235, 266);
			this.bouton_UAC_Desactive.TabIndex = 21;
			this.bouton_UAC_Desactive.Text = " Desactive UAC";
			this.bouton_UAC_Desactive.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_UAC_Desactive.UseVisualStyleBackColor = false;
			this.bouton_UAC_Desactive.Click += new System.EventHandler(this.Bouton_UAC_DesactiveClick);
			// 
			// bouton_nettoyage
			// 
			this.bouton_nettoyage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_nettoyage.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_nettoyage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_nettoyage.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_nettoyage.Image = ((System.Drawing.Image)(resources.GetObject("bouton_nettoyage.Image")));
			this.bouton_nettoyage.Location = new System.Drawing.Point(4, 80);
			this.bouton_nettoyage.Margin = new System.Windows.Forms.Padding(4);
			this.bouton_nettoyage.Name = "bouton_nettoyage";
			this.bouton_nettoyage.Size = new System.Drawing.Size(236, 255);
			this.bouton_nettoyage.TabIndex = 16;
			this.bouton_nettoyage.Text = "7 - NETTOYAGE";
			this.bouton_nettoyage.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_nettoyage.UseVisualStyleBackColor = false;
			this.bouton_nettoyage.Click += new System.EventHandler(this.Bouton_nettoyageClick);
			// 
			// progressBar1
			// 
			this.progressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.tableLayoutPanel1.SetColumnSpan(this.progressBar1, 4);
			this.progressBar1.Location = new System.Drawing.Point(4, 4);
			this.progressBar1.Margin = new System.Windows.Forms.Padding(4);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new System.Drawing.Size(970, 68);
			this.progressBar1.TabIndex = 15;
			// 
			// bouton_pandaCloud
			// 
			this.bouton_pandaCloud.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_pandaCloud.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_pandaCloud.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_pandaCloud.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_pandaCloud.Image = ((System.Drawing.Image)(resources.GetObject("bouton_pandaCloud.Image")));
			this.bouton_pandaCloud.Location = new System.Drawing.Point(248, 80);
			this.bouton_pandaCloud.Margin = new System.Windows.Forms.Padding(4);
			this.bouton_pandaCloud.Name = "bouton_pandaCloud";
			this.bouton_pandaCloud.Size = new System.Drawing.Size(235, 255);
			this.bouton_pandaCloud.TabIndex = 14;
			this.bouton_pandaCloud.Text = "8 - PandaCleaner";
			this.bouton_pandaCloud.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_pandaCloud.UseVisualStyleBackColor = false;
			this.bouton_pandaCloud.Click += new System.EventHandler(this.Bouton_pandaCloudClick);
			// 
			// bouton_Defrag
			// 
			this.bouton_Defrag.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_Defrag.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_Defrag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_Defrag.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_Defrag.Image = ((System.Drawing.Image)(resources.GetObject("bouton_Defrag.Image")));
			this.bouton_Defrag.Location = new System.Drawing.Point(491, 80);
			this.bouton_Defrag.Margin = new System.Windows.Forms.Padding(4);
			this.bouton_Defrag.Name = "bouton_Defrag";
			this.bouton_Defrag.Size = new System.Drawing.Size(236, 255);
			this.bouton_Defrag.TabIndex = 13;
			this.bouton_Defrag.Text = "9 - Disk-Defrag";
			this.bouton_Defrag.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_Defrag.UseVisualStyleBackColor = false;
			this.bouton_Defrag.Click += new System.EventHandler(this.Bouton_DefragClick);
			// 
			// bouton_TeamViewer
			// 
			this.bouton_TeamViewer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_TeamViewer.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_TeamViewer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_TeamViewer.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_TeamViewer.Image = ((System.Drawing.Image)(resources.GetObject("bouton_TeamViewer.Image")));
			this.bouton_TeamViewer.Location = new System.Drawing.Point(735, 80);
			this.bouton_TeamViewer.Margin = new System.Windows.Forms.Padding(4);
			this.bouton_TeamViewer.Name = "bouton_TeamViewer";
			this.bouton_TeamViewer.Size = new System.Drawing.Size(239, 255);
			this.bouton_TeamViewer.TabIndex = 12;
			this.bouton_TeamViewer.Text = "10 - TeamViewer";
			this.bouton_TeamViewer.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_TeamViewer.UseVisualStyleBackColor = false;
			this.bouton_TeamViewer.Click += new System.EventHandler(this.Bouton_TeamViewerClick);
			// 
			// bouton_adwcleaner
			// 
			this.bouton_adwcleaner.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_adwcleaner.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_adwcleaner.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_adwcleaner.ForeColor = System.Drawing.SystemColors.WindowText;
			this.bouton_adwcleaner.Image = ((System.Drawing.Image)(resources.GetObject("bouton_adwcleaner.Image")));
			this.bouton_adwcleaner.Location = new System.Drawing.Point(4, 343);
			this.bouton_adwcleaner.Margin = new System.Windows.Forms.Padding(4);
			this.bouton_adwcleaner.Name = "bouton_adwcleaner";
			this.bouton_adwcleaner.Size = new System.Drawing.Size(236, 266);
			this.bouton_adwcleaner.TabIndex = 11;
			this.bouton_adwcleaner.Text = "11 - ADW Cleaner";
			this.bouton_adwcleaner.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_adwcleaner.UseVisualStyleBackColor = false;
			this.bouton_adwcleaner.Click += new System.EventHandler(this.Bouton_adwcleanerClick);
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.tableLayoutPanel1.ColumnCount = 4;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.88938F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.Controls.Add(this.progressBar1, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.bouton_UAC_Active, 2, 2);
			this.tableLayoutPanel1.Controls.Add(this.bouton_nettoyage, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.bouton_UAC_Desactive, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this.bouton_pandaCloud, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.bouton_adwcleaner, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.bouton_TeamViewer, 3, 1);
			this.tableLayoutPanel1.Controls.Add(this.bouton_Defrag, 2, 1);
			this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 37);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 3;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.39892F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 42.85714F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 44.56522F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(978, 613);
			this.tableLayoutPanel1.TabIndex = 23;
			// 
			// LogicielWiclic
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(1002, 656);
			this.Controls.Add(this.groupBox2);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(1018, 695);
			this.Name = "LogicielWiclic";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Logiciels Wiclic";
			this.groupBox2.ResumeLayout(false);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
