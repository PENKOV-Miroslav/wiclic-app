﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 24/06/2022
 * Heure: 09:33
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Windows.Forms;

namespace ApplicationWiclic
{
	/// <summary>
	/// Description of SiteWebAssurance.
	/// </summary>
	public partial class SiteWebAssurance : Form
	{
		public SiteWebAssurance()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void LinkLabel_furetsLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.lesfurets.com");
		}
		void LinkLabel_assuLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.assu2000.fr/");
		}
		void LinkLabel_OlivierASSULinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.lolivier.fr/");
		}
		void LinkLabel_ActAssuLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.activeassurances.fr/");
		}
		void LinkLabel_AssurpeopleLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.assurpeople.com/");
		}
		void LinkLabel_GMFAssuLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.gmf.fr/");
		}
		void LinkLabel_MAIFLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://agence.maif.fr/assurance/particuliers/");
		}
		void LinkLabel1_MMALinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start ("https://www.mma.fr/");
		}

	}
}
