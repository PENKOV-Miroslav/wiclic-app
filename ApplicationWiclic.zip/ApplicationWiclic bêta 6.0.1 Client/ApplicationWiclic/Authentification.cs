﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 22/06/2022
 * Heure: 11:04
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;

using System.Windows.Forms;

namespace ApplicationWiclic
{
	/// <summary>
	/// Description of Authentification.
	/// </summary>
	public partial class Authentification : Form
	{
		public Authentification()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Bouton_AnnulerClick(object sender, EventArgs e)
		{
			this.Close(); //cela ferme la fenetre de dialogue d'autentification 
		}
		void CheckBox_mdpCheckedChanged(object sender, EventArgs e)
		{
			if (checkBox_mdp.Checked) //la checkBox a deux etat un qui montre les caractaires et un qui va les obstruer rendant le mdp illisible 
				textBox_Login.UseSystemPasswordChar = false;
			else
				textBox_Login.UseSystemPasswordChar =true;
		}
		void Bouton_ConnexionClick(object sender, EventArgs e)
		{
			if (textBox_Nom.Text == "Wiclic")  // les deux conditions de connexion doivent être repsecter sinon cela envoi un message d'erreur
			{
				if (textBox_Login.Text == "WiclicAdmin123")
				{
					
				this.Hide();
				var Authentification = new ControlParental();
				Authentification.ShowDialog();
				Authentification = null;
				this.Show();
				textBox_Nom.Text=String.Empty; //Efface le contenu des textBox et le message d'erreur
		 		textBox_Login.Text=String.Empty; 
		 		label_msgError.Visible =false;
		 		checkBox_mdp.Checked = false ; // Pour Uncheck la box

				}
				else
					label_msgError.Visible =true; //si les conditions de connexion echouent car les mdp ou l'utilisateur sont incorrectes alors on affiche le label d'erreur
			}
			else
					label_msgError.Visible =true;
		}



	}
}
