﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 22/06/2022
 * Heure: 11:04
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic
{
	partial class Authentification
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button bouton_Connexion;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox_Login;
		private System.Windows.Forms.TextBox textBox_Nom;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label_msgError;
		private System.Windows.Forms.CheckBox checkBox_mdp;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.Button bouton_Annuler;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Authentification));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.bouton_Annuler = new System.Windows.Forms.Button();
			this.bouton_Connexion = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.checkBox_mdp = new System.Windows.Forms.CheckBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label_msgError = new System.Windows.Forms.Label();
			this.textBox_Login = new System.Windows.Forms.TextBox();
			this.textBox_Nom = new System.Windows.Forms.TextBox();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.BackColor = System.Drawing.Color.MediumAquamarine;
			this.groupBox1.Controls.Add(this.tableLayoutPanel1);
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox1.ForeColor = System.Drawing.SystemColors.Window;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(571, 393);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "S\'authentifier";
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.MediumAquamarine;
			this.tableLayoutPanel1.ColumnCount = 2;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.8998F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.1002F));
			this.tableLayoutPanel1.Controls.Add(this.bouton_Annuler, 1, 4);
			this.tableLayoutPanel1.Controls.Add(this.bouton_Connexion, 0, 4);
			this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.checkBox_mdp, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this.label1, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.label_msgError, 1, 3);
			this.tableLayoutPanel1.Controls.Add(this.textBox_Login, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.textBox_Nom, 1, 0);
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 38);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 5;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 94F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(565, 345);
			this.tableLayoutPanel1.TabIndex = 9;
			// 
			// bouton_Annuler
			// 
			this.bouton_Annuler.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_Annuler.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.bouton_Annuler.BackColor = System.Drawing.Color.DeepSkyBlue;
			this.bouton_Annuler.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_Annuler.ForeColor = System.Drawing.SystemColors.Window;
			this.bouton_Annuler.Location = new System.Drawing.Point(284, 254);
			this.bouton_Annuler.Name = "bouton_Annuler";
			this.bouton_Annuler.Size = new System.Drawing.Size(278, 88);
			this.bouton_Annuler.TabIndex = 10;
			this.bouton_Annuler.Text = "Annuler";
			this.bouton_Annuler.UseVisualStyleBackColor = false;
			this.bouton_Annuler.Click += new System.EventHandler(this.Bouton_AnnulerClick);
			// 
			// bouton_Connexion
			// 
			this.bouton_Connexion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_Connexion.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.bouton_Connexion.BackColor = System.Drawing.Color.LimeGreen;
			this.bouton_Connexion.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_Connexion.ForeColor = System.Drawing.SystemColors.Window;
			this.bouton_Connexion.Location = new System.Drawing.Point(3, 254);
			this.bouton_Connexion.Name = "bouton_Connexion";
			this.bouton_Connexion.Size = new System.Drawing.Size(275, 88);
			this.bouton_Connexion.TabIndex = 1;
			this.bouton_Connexion.Text = "Connexion";
			this.bouton_Connexion.UseVisualStyleBackColor = false;
			this.bouton_Connexion.Click += new System.EventHandler(this.Bouton_ConnexionClick);
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.label2.BackColor = System.Drawing.Color.MediumAquamarine;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.SystemColors.Window;
			this.label2.Location = new System.Drawing.Point(3, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(275, 81);
			this.label2.TabIndex = 4;
			this.label2.Text = "Identifiant :";
			this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// checkBox_mdp
			// 
			this.checkBox_mdp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.checkBox_mdp.BackColor = System.Drawing.Color.MediumAquamarine;
			this.checkBox_mdp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.checkBox_mdp.ForeColor = System.Drawing.SystemColors.Window;
			this.checkBox_mdp.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
			this.checkBox_mdp.Location = new System.Drawing.Point(284, 165);
			this.checkBox_mdp.Name = "checkBox_mdp";
			this.checkBox_mdp.Size = new System.Drawing.Size(278, 24);
			this.checkBox_mdp.TabIndex = 7;
			this.checkBox_mdp.Text = "Voir le mot de passe";
			this.checkBox_mdp.UseVisualStyleBackColor = false;
			this.checkBox_mdp.CheckedChanged += new System.EventHandler(this.CheckBox_mdpCheckedChanged);
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.label1.BackColor = System.Drawing.Color.MediumAquamarine;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.SystemColors.Window;
			this.label1.Location = new System.Drawing.Point(3, 81);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(275, 81);
			this.label1.TabIndex = 0;
			this.label1.Text = "Saisir le mot de passe :";
			this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label_msgError
			// 
			this.label_msgError.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.label_msgError.BackColor = System.Drawing.Color.MediumAquamarine;
			this.label_msgError.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label_msgError.ForeColor = System.Drawing.Color.Firebrick;
			this.label_msgError.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
			this.label_msgError.Location = new System.Drawing.Point(284, 207);
			this.label_msgError.Name = "label_msgError";
			this.label_msgError.Size = new System.Drawing.Size(278, 44);
			this.label_msgError.TabIndex = 8;
			this.label_msgError.Text = "mot de passe ou identifiant incorrect";
			this.label_msgError.Visible = false;
			// 
			// textBox_Login
			// 
			this.textBox_Login.Location = new System.Drawing.Point(284, 84);
			this.textBox_Login.Name = "textBox_Login";
			this.textBox_Login.Size = new System.Drawing.Size(278, 38);
			this.textBox_Login.TabIndex = 13;
			this.textBox_Login.UseSystemPasswordChar = true;
			// 
			// textBox_Nom
			// 
			this.textBox_Nom.Location = new System.Drawing.Point(284, 3);
			this.textBox_Nom.Name = "textBox_Nom";
			this.textBox_Nom.Size = new System.Drawing.Size(278, 38);
			this.textBox_Nom.TabIndex = 14;
			// 
			// Authentification
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(572, 400);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(477, 439);
			this.Name = "Authentification";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Authentification";
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.ResumeLayout(false);

		}
}
		}


