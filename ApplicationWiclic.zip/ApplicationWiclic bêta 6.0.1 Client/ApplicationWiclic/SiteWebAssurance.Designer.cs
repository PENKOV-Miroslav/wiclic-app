﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 24/06/2022
 * Heure: 09:33
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic
{
	partial class SiteWebAssurance
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.LinkLabel linkLabel_MAIF;
		private System.Windows.Forms.LinkLabel linkLabel_GMFAssu;
		private System.Windows.Forms.LinkLabel linkLabel_Assurpeople;
		private System.Windows.Forms.LinkLabel linkLabel_ActAssu;
		private System.Windows.Forms.LinkLabel linkLabel_OlivierASSU;
		private System.Windows.Forms.LinkLabel linkLabel_assu;
		private System.Windows.Forms.LinkLabel linkLabel_furets;
		private System.Windows.Forms.LinkLabel linkLabel1_MMA;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SiteWebAssurance));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.linkLabel1_MMA = new System.Windows.Forms.LinkLabel();
			this.linkLabel_MAIF = new System.Windows.Forms.LinkLabel();
			this.linkLabel_GMFAssu = new System.Windows.Forms.LinkLabel();
			this.linkLabel_Assurpeople = new System.Windows.Forms.LinkLabel();
			this.linkLabel_ActAssu = new System.Windows.Forms.LinkLabel();
			this.linkLabel_OlivierASSU = new System.Windows.Forms.LinkLabel();
			this.linkLabel_assu = new System.Windows.Forms.LinkLabel();
			this.linkLabel_furets = new System.Windows.Forms.LinkLabel();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.BackColor = System.Drawing.Color.MediumAquamarine;
			this.groupBox1.Controls.Add(this.linkLabel1_MMA);
			this.groupBox1.Controls.Add(this.linkLabel_MAIF);
			this.groupBox1.Controls.Add(this.linkLabel_GMFAssu);
			this.groupBox1.Controls.Add(this.linkLabel_Assurpeople);
			this.groupBox1.Controls.Add(this.linkLabel_ActAssu);
			this.groupBox1.Controls.Add(this.linkLabel_OlivierASSU);
			this.groupBox1.Controls.Add(this.linkLabel_assu);
			this.groupBox1.Controls.Add(this.linkLabel_furets);
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox1.ForeColor = System.Drawing.SystemColors.Window;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(540, 338);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Les autres sites des Assureurs";
			// 
			// linkLabel1_MMA
			// 
			this.linkLabel1_MMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel1_MMA.Location = new System.Drawing.Point(85, 273);
			this.linkLabel1_MMA.Name = "linkLabel1_MMA";
			this.linkLabel1_MMA.Size = new System.Drawing.Size(311, 35);
			this.linkLabel1_MMA.TabIndex = 7;
			this.linkLabel1_MMA.TabStop = true;
			this.linkLabel1_MMA.Text = "MMA Assurance";
			this.linkLabel1_MMA.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel1_MMALinkClicked);
			// 
			// linkLabel_MAIF
			// 
			this.linkLabel_MAIF.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_MAIF.Location = new System.Drawing.Point(85, 242);
			this.linkLabel_MAIF.Name = "linkLabel_MAIF";
			this.linkLabel_MAIF.Size = new System.Drawing.Size(311, 31);
			this.linkLabel_MAIF.TabIndex = 6;
			this.linkLabel_MAIF.TabStop = true;
			this.linkLabel_MAIF.Text = "MAIF Assurance";
			this.linkLabel_MAIF.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_MAIFLinkClicked);
			// 
			// linkLabel_GMFAssu
			// 
			this.linkLabel_GMFAssu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_GMFAssu.Location = new System.Drawing.Point(85, 211);
			this.linkLabel_GMFAssu.Name = "linkLabel_GMFAssu";
			this.linkLabel_GMFAssu.Size = new System.Drawing.Size(311, 31);
			this.linkLabel_GMFAssu.TabIndex = 5;
			this.linkLabel_GMFAssu.TabStop = true;
			this.linkLabel_GMFAssu.Text = "GMF Assurances";
			this.linkLabel_GMFAssu.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_GMFAssuLinkClicked);
			// 
			// linkLabel_Assurpeople
			// 
			this.linkLabel_Assurpeople.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_Assurpeople.Location = new System.Drawing.Point(85, 180);
			this.linkLabel_Assurpeople.Name = "linkLabel_Assurpeople";
			this.linkLabel_Assurpeople.Size = new System.Drawing.Size(311, 31);
			this.linkLabel_Assurpeople.TabIndex = 4;
			this.linkLabel_Assurpeople.TabStop = true;
			this.linkLabel_Assurpeople.Text = "Assurpeople";
			this.linkLabel_Assurpeople.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_AssurpeopleLinkClicked);
			// 
			// linkLabel_ActAssu
			// 
			this.linkLabel_ActAssu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_ActAssu.Location = new System.Drawing.Point(85, 149);
			this.linkLabel_ActAssu.Name = "linkLabel_ActAssu";
			this.linkLabel_ActAssu.Size = new System.Drawing.Size(311, 31);
			this.linkLabel_ActAssu.TabIndex = 3;
			this.linkLabel_ActAssu.TabStop = true;
			this.linkLabel_ActAssu.Text = "Active Assurances";
			this.linkLabel_ActAssu.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_ActAssuLinkClicked);
			// 
			// linkLabel_OlivierASSU
			// 
			this.linkLabel_OlivierASSU.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_OlivierASSU.Location = new System.Drawing.Point(85, 118);
			this.linkLabel_OlivierASSU.Name = "linkLabel_OlivierASSU";
			this.linkLabel_OlivierASSU.Size = new System.Drawing.Size(311, 31);
			this.linkLabel_OlivierASSU.TabIndex = 2;
			this.linkLabel_OlivierASSU.TabStop = true;
			this.linkLabel_OlivierASSU.Text = "Olivier Assurance";
			this.linkLabel_OlivierASSU.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_OlivierASSULinkClicked);
			// 
			// linkLabel_assu
			// 
			this.linkLabel_assu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_assu.Location = new System.Drawing.Point(85, 87);
			this.linkLabel_assu.Name = "linkLabel_assu";
			this.linkLabel_assu.Size = new System.Drawing.Size(311, 31);
			this.linkLabel_assu.TabIndex = 1;
			this.linkLabel_assu.TabStop = true;
			this.linkLabel_assu.Text = "ASSU 2000";
			this.linkLabel_assu.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_assuLinkClicked);
			// 
			// linkLabel_furets
			// 
			this.linkLabel_furets.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_furets.Location = new System.Drawing.Point(85, 56);
			this.linkLabel_furets.Name = "linkLabel_furets";
			this.linkLabel_furets.Size = new System.Drawing.Size(311, 31);
			this.linkLabel_furets.TabIndex = 0;
			this.linkLabel_furets.TabStop = true;
			this.linkLabel_furets.Text = "Les Furets";
			this.linkLabel_furets.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_furetsLinkClicked);
			// 
			// SiteWebAssurance
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(539, 338);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximumSize = new System.Drawing.Size(555, 377);
			this.MinimumSize = new System.Drawing.Size(555, 377);
			this.Name = "SiteWebAssurance";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Sites Web Assurance";
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
