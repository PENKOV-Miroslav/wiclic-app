﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 13/06/2022
 * Heure: 09:56
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics; //Permet l'execution de fichier
using System.IO; // voir si le fichier existe


namespace ApplicationWiclic
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		// Ce bouton permet au client de contacter le support via un formulaire qui s'affiche dans une fenetre séparer 
		void Bouton_supportClick(object sender, EventArgs e)
		{
			var NousContacter = new NousContacter();
			NousContacter.ShowDialog();
			NousContacter = null;
			this.Show();
		}
		//Bouton pour voir le site de Wiclic
		void Bouton_siteWebClick(object sender, EventArgs e)
		{
			try
            {
				Process.Start("https://www.wiclic.fr/");
			}
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		//Bouton pour voir les actualités cyber-attaques...
		void Bouton_actuClick(object sender, EventArgs e)
		{
			try
            {
				Process.Start("https://www.wiclic.fr/category/actualites-informatiques/");
			}
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		//Bouton pour lancer TeamViewer
		void Bouton_teleassistanceClick(object sender, EventArgs e)
		{
			try
            {
				//instancie le chemin d'accès universel à l'application TeamViewer
				string TeamViewerQS = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TeamViewerAbo.exe");
				Process.Start(TeamViewerQS);
			}
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		
		void Bouton_siteRecommanderClick(object sender, EventArgs e) // le bouton permet d'ouvrir la fenetre des sites Recommandés
		{
			var Websites = new Websites();
			Websites.ShowDialog();
			Websites = null;
			this.Show();
		}
		
		void Bouton_controleClick(object sender, EventArgs e) // le bouton permet d'ouvrir la fenetre du controle parental
		{
			var Authentification = new Authentification();
			Authentification.ShowDialog();
			Authentification = null;
			this.Show();
		}
		void Bouton_wiclicAppsClick(object sender, EventArgs e)
		{
			var LogicielWiclic = new LogicielWiclic();
			LogicielWiclic.ShowDialog();
			LogicielWiclic = null;
			this.Show();
		}


       
	}
}
