﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 20/06/2022
 * Heure: 16:47
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Windows.Forms;

namespace ApplicationWiclic
{
	/// <summary>
	/// Description of SiteWebGouv.
	/// </summary>
	public partial class SiteWebGouv : Form
	{
		public SiteWebGouv()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void LinkLabel_wikiLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{  
    		System.Diagnostics.Process.Start("https://ants.gouv.fr/");
		}
		void LinkLabel_frconnectLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start("https://franceconnect.gouv.fr/");
		}
		void LinkLabel_cafLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start("https://www.caf.fr/");
		}
	}
}
