﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 13/06/2022
 * Heure: 10:34
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Windows.Forms;
using System.Text.RegularExpressions; //permet de limiter le texte suivant des conditions spécifique attribuer au RegEx
namespace ApplicationWiclic
{
	/// <summary>
	/// Description of NousContacter.
	/// </summary>
	public partial class NousContacter : Form
	{
		public NousContacter()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		Client ApplicationWiclic = new Client(); //instanciation du nouvelle objet ApplicationWiclic via la classe Utilisateur
		void Bouton_ENVOYERClick(object sender, EventArgs e)
		{
			try{ //essaye d'executer les commande suivante et si echeque affiche un message d'erreur via le catch
				
		 ApplicationWiclic.setnomFamille( textBox1.Text);
		 ApplicationWiclic.setprenom( textBox2.Text);
		 ApplicationWiclic.setaddresseMail( textBox3.Text);
		 ApplicationWiclic.settelephone( textBox4.Text);
		 ApplicationWiclic.settexte( textBox5.Text);
		 const string  strRegexTel = "^(?:(?:\\+|00)33|0)\\s*[1-9](?:[\\s.-]*\\d{2}){4}$"; //pattern verifiant le numero uniquement telephone de la France
		 const string strRegexMail = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" + @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" + @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"; //pattern qui verifie l'e-mail sui la synthaxe est correcte avec un bon nom de domaine
		 Regex regexMail = new Regex(strRegexMail); //instanciation d'un nouveau RegEx limitant les caractaires du mail
		 Regex regexTel = new Regex(strRegexTel); //instanciation d'un nouveau RegEx limitant les caractaires du telephone


				if(regexTel.IsMatch(ApplicationWiclic.gettelephone())) {			//Si les conditions précedaments sont respecter alors on procedé a l'execution de la methodes create
					 if(regexMail.IsMatch(ApplicationWiclic.getaddresseMail())) {
						 BDD.connexion();
						 ApplicationWiclic.create(); //appele la methode de creation du ticket de support
						 textBox1.Text=String.Empty; //Efface le contenu des textBox
						 textBox2.Text=String.Empty;
						 textBox3.Text=String.Empty;
						 textBox4.Text=String.Empty;
						 textBox5.Text=String.Empty;
						 MessageBox.Show(" Votre demande a bien été transmise "); //message avertissant de la création du ticket
						 this.Close();
							}
					 	else{
						 	MessageBox.Show(" Votre  mail  est incorrectement saisi,réessayé "); //se message s'affiche lorsque le client n'a pas saisi une adresse mail valide
						 	textBox3.Text=String.Empty;
						 }
					}
				 		else{
						 	MessageBox.Show(" Votre telephone est incorrectement saisi,réessayé "); //se message s'affiche lorsque le client n'a pas saisi un telephone valide
						 	textBox4.Text=String.Empty;
		
						 }
			 }
			
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}

		void Bouton_ANNULERClick(object sender, EventArgs e) // Bouton qui permet la fermeture de la fenetre 
		{
			this.Close();

		}






	}
}
