﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 20/06/2022
 * Heure: 17:14
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.ComponentModel; // permet d'implémenter le comportement au moment de l’exécution et de la conception des composants et des contrôles.
using System.Linq; // Il fournit une solution au problème du mappage objet-relationnel et simplifie l’interaction entre les objets et les sources de données
using System.Windows.Forms;
using System.Diagnostics; //Permet l'execution de fichier
using System.Net; //connexion a internet
using System.IO; // voir si le fichier existe

namespace ApplicationWiclic
{
	/// <summary>
	/// Description of LogicielWiclic.
	/// </summary>
	public partial class LogicielWiclic : Form
	{
		public LogicielWiclic()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		Client ApplicationWiclic = new Client();
		//J'instancie les url des programmes a telecharger
		//lien vers TeamViewerQS et son chemin ou le fichier sera télécharger 
		Uri uri = new Uri("https://www.wiclic.fr/documents/TeamViewerAbo.exe"); 
		//chemain d'accees au fichier telecharger par l'url
       string filename = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TeamViewerAbo.exe");
       
       //lien vers pandacloudcleaner et son chemin ou le fichier sera télécharger
       Uri uri2 = new Uri("https://repository.pandasecurity.com/pandacloudcleaner/installers/activescan/PandaCloudCleaner.exe?_ga=2.244415877.1095533330.1606738494-1615372525.1605280137");
       //chemain d'accees au fichier telecharger par l'url
       string filename2 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PandaCloudCleaner.exe");
       
       //lien vers ausdiskdefrag et son chemin ou le fichier sera télécharger
       Uri uri3 = new Uri("https://www.wiclic.fr/documents/ausdiskdefrag.exe");
       //chemain d'accees au fichier telecharger par l'url
       string filename3 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ausdiskdefrag.exe");
       
       //lien vers adwcleaner et son chemin ou le fichier sera télécharger
       Uri uri4 = new Uri("https://downloads.malwarebytes.com/file/adwcleaner");
       string filename4 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "adwcleaner.exe");
       
       //Ce bouton permet de telecharger l'outil pandacleaner et de l'executer directement apres son telechargement
		void Bouton_pandaCloudClick(object sender, EventArgs e)
{
			{
		try
        {
			//Condition d'existance du fichier si existant on le supprime puis on procede au telechargement de celui-ci
            if (File.Exists(filename2))
            {
                File.Delete(filename2);
            }

            var wc = new WebClient(); //création de variable webclient
            wc.DownloadFileAsync(uri2, filename2);
            wc.DownloadProgressChanged += new DownloadProgressChangedEventHandler(wc_DownloadProgressChanged2);
            wc.DownloadFileCompleted += new AsyncCompletedEventHandler(wc_DownloadFileCompleted2);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }

    }
}
	//cela permet de mettre a jour la bar de chargement du programme
    private void wc_DownloadProgressChanged2(object sender, DownloadProgressChangedEventArgs e)
    {
        progressBar1.Value = e.ProgressPercentage;
        if (progressBar1.Value == progressBar1.Maximum)
        {
            progressBar1.Value = 0;
        }
    }
    //lorsque le telechargement et fini cela va executer le programme et procéder a l'installation de celui-ci
    private void wc_DownloadFileCompleted2(object sender, AsyncCompletedEventArgs e)
    {
        if (e.Error == null)
        {
            Process.Start(filename2);
        }
        else
        {
            MessageBox.Show("Impossible de télécharger l'application, veuillez vérifier votre connexion », « Échec du téléchargement!");
        }

		}
    //Ce bouton permet de telecharger l'outil Defrag et de l'executer directement apres son telechargement
		void Bouton_DefragClick(object sender, EventArgs e)
{
			try
        {
            if (File.Exists(filename3))
            {
                File.Delete(filename3);
            }

            var wc = new WebClient();
            wc.DownloadFileAsync(uri3, filename3);
            wc.DownloadProgressChanged += new DownloadProgressChangedEventHandler(wc_DownloadProgressChanged3);
            wc.DownloadFileCompleted += new AsyncCompletedEventHandler(wc_DownloadFileCompleted3);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message.ToString());
        }

    }

    private void wc_DownloadProgressChanged3(object sender, DownloadProgressChangedEventArgs e)
    {
        progressBar1.Value = e.ProgressPercentage;
        if (progressBar1.Value == progressBar1.Maximum)
        {
            progressBar1.Value = 0;
        }
    }
    private void wc_DownloadFileCompleted3(object sender, AsyncCompletedEventArgs e)
    {
        if (e.Error == null)
        {
            Process.Start(filename3);

        }
        else
        {
            MessageBox.Show("Impossible de télécharger l'application, veuillez vérifier votre connexion », « Échec du téléchargement!");
        }
		}
    
    //Ce bouton permet de telecharger l'outil TeamViewer et de l'executer directement apres son telechargement
		void Bouton_TeamViewerClick(object sender, EventArgs e)
{
			try
        {
            if (File.Exists(filename))
            {
                File.Delete(filename);
            }

            var wc = new WebClient();
            wc.DownloadFileAsync(uri, filename);
            wc.DownloadProgressChanged += new DownloadProgressChangedEventHandler(wc_DownloadProgressChanged);
            wc.DownloadFileCompleted += new AsyncCompletedEventHandler(wc_DownloadFileCompleted);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }

    }

    private void wc_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
    {
        progressBar1.Value = e.ProgressPercentage;
        if (progressBar1.Value == progressBar1.Maximum)
        {
            progressBar1.Value = 0;
        }
    }
    private void wc_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
    {
        if (e.Error == null)
        {
            Process.Start(filename);

        }
        else
        {
            MessageBox.Show("Impossible de télécharger l'application, veuillez vérifier votre connexion », « Échec du téléchargement!");
        }
		}
		void Bouton_adwcleanerClick(object sender, EventArgs e)
{
			try
        {
            if (File.Exists(filename4))
            {
                File.Delete(filename4);
            }

            var wc = new WebClient();
            wc.DownloadFileAsync(uri4, filename4);
            wc.DownloadProgressChanged += new DownloadProgressChangedEventHandler(wc_DownloadProgressChanged4);
            wc.DownloadFileCompleted += new AsyncCompletedEventHandler(wc_DownloadFileCompleted4);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }

    }

    private void wc_DownloadProgressChanged4(object sender, DownloadProgressChangedEventArgs e)
    {
        progressBar1.Value = e.ProgressPercentage;
        if (progressBar1.Value == progressBar1.Maximum)
        {
            progressBar1.Value = 0;
        }
    }
    private void wc_DownloadFileCompleted4(object sender, AsyncCompletedEventArgs e)
    {
        if (e.Error == null)
        {
            Process.Start(filename4);

        }
        else
        {
            MessageBox.Show("Impossible de télécharger l'application, veuillez vérifier votre connexion », « Échec du téléchargement!");
        }
		}
		void Bouton_nettoyageClick(object sender, EventArgs e)
		{
			try
            {
				//On appele les applications à démarer et proceder au nettoyage
             	Process.Start(@"C:\Program Files (x86)\Panda Security\Panda Cloud Cleaner\PCloudCleaner.exe");
             string ausdiskdefrag = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ausdiskdefrag.exe");
				Process.Start(ausdiskdefrag); 
			 string adwcleaner = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "adwcleaner.exe");
				Process.Start(adwcleaner);


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		
		void Bouton_UAC_DesactiveClick(object sender, EventArgs e)	//permet de Desactiver l'UAC en executant la commande via la voix admin
		{
		try{
			 ApplicationWiclic.ExecuteAsAdmin("CMD.exe","/K reg.exe ADD HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v EnableLUA /t REG_DWORD /d 0 /f  && exit");
			 MessageBox.Show("Redémarrer votre ordinateur pour appliquer les changements");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_UAC_ActiveClick(object sender, EventArgs e)	//permet d'activer l'UAC en executant la commande via la voix admin
		{
			try{
				ApplicationWiclic.ExecuteAsAdmin("CMD.exe","/K reg.exe ADD HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v EnableLUA /t REG_DWORD /d 1 /f  && exit");
				MessageBox.Show("Redémarrer votre ordinateur pour appliquer les changements");
			}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}

	}
}
