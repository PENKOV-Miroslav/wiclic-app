﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 15/06/2022
 * Heure: 10:32
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic
{
	partial class ControlParental
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button bouton_desactiveTout;
		private System.Windows.Forms.Button bouton_optionLimiteTemps1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button bouton_optionLimiteTemps2;
		private System.Windows.Forms.Button bouton_optionLimiteTemps3;
		private System.Windows.Forms.Button bouton_optionLimiteTemps4;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Button bouton_optionSiteWeb1;
		private System.Windows.Forms.Button bouton_optionSiteWeb4;
		private System.Windows.Forms.Button bouton_optionSiteWeb2;
		private System.Windows.Forms.Button bouton_optionSiteWeb3;
		private System.Windows.Forms.Button AnnuletTempsLimite;
		private System.Windows.Forms.Button AnnuletLimiteWeb;
		private System.Windows.Forms.Button bouton_WiclicCenter;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ControlParental));
			this.bouton_desactiveTout = new System.Windows.Forms.Button();
			this.bouton_optionLimiteTemps1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.bouton_optionLimiteTemps2 = new System.Windows.Forms.Button();
			this.bouton_optionLimiteTemps3 = new System.Windows.Forms.Button();
			this.bouton_optionLimiteTemps4 = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.AnnuletTempsLimite = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.AnnuletLimiteWeb = new System.Windows.Forms.Button();
			this.bouton_optionSiteWeb1 = new System.Windows.Forms.Button();
			this.bouton_optionSiteWeb4 = new System.Windows.Forms.Button();
			this.bouton_optionSiteWeb2 = new System.Windows.Forms.Button();
			this.bouton_optionSiteWeb3 = new System.Windows.Forms.Button();
			this.bouton_WiclicCenter = new System.Windows.Forms.Button();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// bouton_desactiveTout
			// 
			this.bouton_desactiveTout.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_desactiveTout.BackColor = System.Drawing.Color.LightBlue;
			this.bouton_desactiveTout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_desactiveTout.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_desactiveTout.Location = new System.Drawing.Point(4, 348);
			this.bouton_desactiveTout.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.bouton_desactiveTout.Name = "bouton_desactiveTout";
			this.bouton_desactiveTout.Size = new System.Drawing.Size(348, 98);
			this.bouton_desactiveTout.TabIndex = 15;
			this.bouton_desactiveTout.Text = "DESACTIVER TOUT";
			this.bouton_desactiveTout.UseVisualStyleBackColor = false;
			this.bouton_desactiveTout.Click += new System.EventHandler(this.Bouton_desactiveToutClick);
			// 
			// bouton_optionLimiteTemps1
			// 
			this.bouton_optionLimiteTemps1.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_optionLimiteTemps1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_optionLimiteTemps1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_optionLimiteTemps1.Location = new System.Drawing.Point(9, 32);
			this.bouton_optionLimiteTemps1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.bouton_optionLimiteTemps1.Name = "bouton_optionLimiteTemps1";
			this.bouton_optionLimiteTemps1.Size = new System.Drawing.Size(334, 44);
			this.bouton_optionLimiteTemps1.TabIndex = 14;
			this.bouton_optionLimiteTemps1.Text = "Limiter le PC pendant 1 h";
			this.bouton_optionLimiteTemps1.UseVisualStyleBackColor = false;
			this.bouton_optionLimiteTemps1.Click += new System.EventHandler(this.Bouton_optionLimiteTemps1Click);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.SystemColors.Window;
			this.label1.Location = new System.Drawing.Point(260, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(257, 36);
			this.label1.TabIndex = 16;
			this.label1.Text = "Controle du poste";
			// 
			// bouton_optionLimiteTemps2
			// 
			this.bouton_optionLimiteTemps2.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_optionLimiteTemps2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_optionLimiteTemps2.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_optionLimiteTemps2.Location = new System.Drawing.Point(9, 89);
			this.bouton_optionLimiteTemps2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.bouton_optionLimiteTemps2.Name = "bouton_optionLimiteTemps2";
			this.bouton_optionLimiteTemps2.Size = new System.Drawing.Size(334, 44);
			this.bouton_optionLimiteTemps2.TabIndex = 17;
			this.bouton_optionLimiteTemps2.Text = "Limiter le PC pendant 2 h";
			this.bouton_optionLimiteTemps2.UseVisualStyleBackColor = false;
			this.bouton_optionLimiteTemps2.Click += new System.EventHandler(this.Bouton_optionLimiteTemps2Click);
			// 
			// bouton_optionLimiteTemps3
			// 
			this.bouton_optionLimiteTemps3.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_optionLimiteTemps3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_optionLimiteTemps3.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_optionLimiteTemps3.Location = new System.Drawing.Point(9, 145);
			this.bouton_optionLimiteTemps3.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.bouton_optionLimiteTemps3.Name = "bouton_optionLimiteTemps3";
			this.bouton_optionLimiteTemps3.Size = new System.Drawing.Size(334, 44);
			this.bouton_optionLimiteTemps3.TabIndex = 18;
			this.bouton_optionLimiteTemps3.Text = "Limiter le PC pendant 3 h";
			this.bouton_optionLimiteTemps3.UseVisualStyleBackColor = false;
			this.bouton_optionLimiteTemps3.Click += new System.EventHandler(this.Bouton_optionLimiteTemps3Click);
			// 
			// bouton_optionLimiteTemps4
			// 
			this.bouton_optionLimiteTemps4.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_optionLimiteTemps4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_optionLimiteTemps4.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_optionLimiteTemps4.Location = new System.Drawing.Point(9, 202);
			this.bouton_optionLimiteTemps4.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.bouton_optionLimiteTemps4.Name = "bouton_optionLimiteTemps4";
			this.bouton_optionLimiteTemps4.Size = new System.Drawing.Size(334, 44);
			this.bouton_optionLimiteTemps4.TabIndex = 19;
			this.bouton_optionLimiteTemps4.Text = "Limiter le PC pendant 4 h";
			this.bouton_optionLimiteTemps4.UseVisualStyleBackColor = false;
			this.bouton_optionLimiteTemps4.Click += new System.EventHandler(this.Bouton_optionLimiteTemps4Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.BackColor = System.Drawing.Color.MediumAquamarine;
			this.groupBox1.Controls.Add(this.AnnuletTempsLimite);
			this.groupBox1.Controls.Add(this.bouton_optionLimiteTemps1);
			this.groupBox1.Controls.Add(this.bouton_optionLimiteTemps4);
			this.groupBox1.Controls.Add(this.bouton_optionLimiteTemps2);
			this.groupBox1.Controls.Add(this.bouton_optionLimiteTemps3);
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox1.ForeColor = System.Drawing.SystemColors.Window;
			this.groupBox1.Location = new System.Drawing.Point(3, 4);
			this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox1.Size = new System.Drawing.Size(350, 334);
			this.groupBox1.TabIndex = 20;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Limite d\'heure ";
			// 
			// AnnuletTempsLimite
			// 
			this.AnnuletTempsLimite.BackColor = System.Drawing.Color.LightBlue;
			this.AnnuletTempsLimite.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.AnnuletTempsLimite.ForeColor = System.Drawing.SystemColors.ControlText;
			this.AnnuletTempsLimite.Location = new System.Drawing.Point(9, 258);
			this.AnnuletTempsLimite.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.AnnuletTempsLimite.Name = "AnnuletTempsLimite";
			this.AnnuletTempsLimite.Size = new System.Drawing.Size(334, 66);
			this.AnnuletTempsLimite.TabIndex = 20;
			this.AnnuletTempsLimite.Text = "Annuler la limite de temps";
			this.AnnuletTempsLimite.UseVisualStyleBackColor = false;
			this.AnnuletTempsLimite.Click += new System.EventHandler(this.AnnuletTempsLimiteClick);
			// 
			// groupBox2
			// 
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox2.BackColor = System.Drawing.Color.MediumAquamarine;
			this.groupBox2.Controls.Add(this.AnnuletLimiteWeb);
			this.groupBox2.Controls.Add(this.bouton_optionSiteWeb1);
			this.groupBox2.Controls.Add(this.bouton_optionSiteWeb4);
			this.groupBox2.Controls.Add(this.bouton_optionSiteWeb2);
			this.groupBox2.Controls.Add(this.bouton_optionSiteWeb3);
			this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox2.ForeColor = System.Drawing.SystemColors.Window;
			this.groupBox2.Location = new System.Drawing.Point(359, 4);
			this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox2.Size = new System.Drawing.Size(351, 334);
			this.groupBox2.TabIndex = 21;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Limite Sites web";
			// 
			// AnnuletLimiteWeb
			// 
			this.AnnuletLimiteWeb.BackColor = System.Drawing.Color.LightBlue;
			this.AnnuletLimiteWeb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.AnnuletLimiteWeb.ForeColor = System.Drawing.SystemColors.ControlText;
			this.AnnuletLimiteWeb.Location = new System.Drawing.Point(9, 264);
			this.AnnuletLimiteWeb.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.AnnuletLimiteWeb.Name = "AnnuletLimiteWeb";
			this.AnnuletLimiteWeb.Size = new System.Drawing.Size(335, 61);
			this.AnnuletLimiteWeb.TabIndex = 20;
			this.AnnuletLimiteWeb.Text = "Annuler limite site web";
			this.AnnuletLimiteWeb.UseVisualStyleBackColor = false;
			this.AnnuletLimiteWeb.Click += new System.EventHandler(this.AnnuletLimiteWebClick);
			// 
			// bouton_optionSiteWeb1
			// 
			this.bouton_optionSiteWeb1.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_optionSiteWeb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_optionSiteWeb1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_optionSiteWeb1.Location = new System.Drawing.Point(9, 32);
			this.bouton_optionSiteWeb1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.bouton_optionSiteWeb1.Name = "bouton_optionSiteWeb1";
			this.bouton_optionSiteWeb1.Size = new System.Drawing.Size(335, 41);
			this.bouton_optionSiteWeb1.TabIndex = 14;
			this.bouton_optionSiteWeb1.Text = "Sites pour adultes ";
			this.bouton_optionSiteWeb1.UseVisualStyleBackColor = false;
			this.bouton_optionSiteWeb1.Click += new System.EventHandler(this.Bouton_optionSiteWeb1Click);
			// 
			// bouton_optionSiteWeb4
			// 
			this.bouton_optionSiteWeb4.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_optionSiteWeb4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_optionSiteWeb4.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_optionSiteWeb4.Location = new System.Drawing.Point(9, 191);
			this.bouton_optionSiteWeb4.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.bouton_optionSiteWeb4.Name = "bouton_optionSiteWeb4";
			this.bouton_optionSiteWeb4.Size = new System.Drawing.Size(335, 61);
			this.bouton_optionSiteWeb4.TabIndex = 19;
			this.bouton_optionSiteWeb4.Text = "Limiter le PC pendant 4 h et limite les site web";
			this.bouton_optionSiteWeb4.UseVisualStyleBackColor = false;
			this.bouton_optionSiteWeb4.Click += new System.EventHandler(this.Bouton_optionSiteWeb4Click);
			// 
			// bouton_optionSiteWeb2
			// 
			this.bouton_optionSiteWeb2.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_optionSiteWeb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_optionSiteWeb2.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_optionSiteWeb2.Location = new System.Drawing.Point(9, 85);
			this.bouton_optionSiteWeb2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.bouton_optionSiteWeb2.Name = "bouton_optionSiteWeb2";
			this.bouton_optionSiteWeb2.Size = new System.Drawing.Size(335, 41);
			this.bouton_optionSiteWeb2.TabIndex = 17;
			this.bouton_optionSiteWeb2.Text = "Jeux d\'argent";
			this.bouton_optionSiteWeb2.UseVisualStyleBackColor = false;
			this.bouton_optionSiteWeb2.Click += new System.EventHandler(this.Bouton_optionSiteWeb2Click);
			// 
			// bouton_optionSiteWeb3
			// 
			this.bouton_optionSiteWeb3.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_optionSiteWeb3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_optionSiteWeb3.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_optionSiteWeb3.Location = new System.Drawing.Point(9, 138);
			this.bouton_optionSiteWeb3.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.bouton_optionSiteWeb3.Name = "bouton_optionSiteWeb3";
			this.bouton_optionSiteWeb3.Size = new System.Drawing.Size(335, 41);
			this.bouton_optionSiteWeb3.TabIndex = 18;
			this.bouton_optionSiteWeb3.Text = "Contenu violent";
			this.bouton_optionSiteWeb3.UseVisualStyleBackColor = false;
			this.bouton_optionSiteWeb3.Click += new System.EventHandler(this.Bouton_optionSiteWeb3Click);
			// 
			// bouton_WiclicCenter
			// 
			this.bouton_WiclicCenter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_WiclicCenter.BackColor = System.Drawing.Color.LightGreen;
			this.bouton_WiclicCenter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bouton_WiclicCenter.ForeColor = System.Drawing.SystemColors.ControlText;
			this.bouton_WiclicCenter.Location = new System.Drawing.Point(360, 348);
			this.bouton_WiclicCenter.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.bouton_WiclicCenter.Name = "bouton_WiclicCenter";
			this.bouton_WiclicCenter.Size = new System.Drawing.Size(349, 98);
			this.bouton_WiclicCenter.TabIndex = 22;
			this.bouton_WiclicCenter.Text = "Revenir en Arriere";
			this.bouton_WiclicCenter.UseVisualStyleBackColor = false;
			this.bouton_WiclicCenter.Click += new System.EventHandler(this.Bouton_WiclicCenterClick);
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.tableLayoutPanel1.ColumnCount = 2;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.Controls.Add(this.groupBox2, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.bouton_WiclicCenter, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.bouton_desactiveTout, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 0);
			this.tableLayoutPanel1.Location = new System.Drawing.Point(33, 58);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 2;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75.70281F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.29719F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(713, 452);
			this.tableLayoutPanel1.TabIndex = 23;
			// 
			// ControlParental
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumAquamarine;
			this.ClientSize = new System.Drawing.Size(788, 530);
			this.Controls.Add(this.tableLayoutPanel1);
			this.Controls.Add(this.label1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.MinimumSize = new System.Drawing.Size(804, 569);
			this.Name = "ControlParental";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Control Parental";
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
