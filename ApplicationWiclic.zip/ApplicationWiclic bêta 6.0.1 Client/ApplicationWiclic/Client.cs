﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 13/06/2022
 * Heure: 10:46
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Linq;
using MySql.Data.MySqlClient; // connexion via une BDD MySQL
using System.Diagnostics; //Permet l'execution de fichier

namespace ApplicationWiclic
{
	/// <summary>
	/// Description of Client.
	/// </summary>
	public class Client
	{
		//attribut privé
			private String nomFamille;
	 		private String prenom;
			private String addresseMail;
			private String telephone;
			private String texte;
			private int heure;
			private int minutes ;

		//Le constructeur permet au programmeur de définir des valeurs par défaut	
		public Client(){}
		public Client(String nomFamille, String prenom, String addresseMail,String telephone,String texte,int heure,int minutes)
		{
				this.nomFamille=nomFamille;
	 			this.prenom=prenom;
	 			this.addresseMail=addresseMail;
	 			this.telephone=telephone;
	 			this.texte=texte;
	 			this.heure=heure;
	 			this.minutes=minutes;

		}
		
		//setter

		public void setnomFamille(String nomFamille){
			this.nomFamille=nomFamille;
		}
		public void setprenom(String prenom){
			this.prenom=prenom;
		}
		public void setaddresseMail(String addresseMail){
			this.addresseMail=addresseMail;
		}
		public void settelephone(String telephone){
			this.telephone=telephone;
		}
		public void settexte(String texte){
			this.texte=texte;
		}
		public void setheure(int heure){
			this.heure=heure;
		}
		public void setminutes(int minutes){
			this.minutes=minutes;
		}


		//getter
		
		public String getnomFamille(){
		return this.nomFamille;
		}
		public String getprenom(){
		return this.prenom;
		}
		public String getaddresseMail(){
		return this.addresseMail;
		}
		public String gettelephone(){
		return this.telephone;
		} 
		public String gettexte(){
		return this.texte;
		} 
		public String getheure(){
			return this.heure.ToString();
		} 
		public String getminutes(){
			return this.minutes.ToString();
		} 
		
		//méhode de création
		public void create( ) {
		 // Connexion à la base de données
		 BDD.connexion();
		 String req = "INSERT INTO nouscontacter ( nom, prenom, adresse, telephone, texte) VALUES ('"+this.nomFamille+"','"+this.prenom+"','"+this.addresseMail+"','"+this.telephone+"','"+this.texte+"')"; //declaration de la requete SQL qui sera utiliser pour la création
		 MySqlCommand cmd = new MySqlCommand(req, BDD.maconnexion);
		 cmd.ExecuteNonQuery( );
		 
		}
		//Methode d'execution d'un logiciel en mode admin et d'une commande qu'il doit executer
		public void ExecuteAsAdmin(string fileName,string command)
		{
		    Process proc = new Process(); //création d'un nouveau process
		    proc.StartInfo.FileName = fileName; //cherche le filname attribuer
		    proc.StartInfo.Arguments = command; //cherche l'argument attribuer
		    proc.StartInfo.UseShellExecute = true; //fenetre admin s'affiche
		    proc.StartInfo.Verb = "runas";
		    proc.Start();  //on lance le programme en mode "comme admin"

		}
	

		}
			
}