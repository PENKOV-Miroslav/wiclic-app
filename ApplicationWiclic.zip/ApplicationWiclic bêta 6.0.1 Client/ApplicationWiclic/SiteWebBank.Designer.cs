﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 24/06/2022
 * Heure: 09:10
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic
{
	partial class SiteWebBank
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.LinkLabel linkLabel_frconnect;
		private System.Windows.Forms.LinkLabel linkLabel_wiki;
		private System.Windows.Forms.LinkLabel linkLabel_BfB;
		private System.Windows.Forms.LinkLabel linkLabel_helloBQ;
		private System.Windows.Forms.LinkLabel linkLabel_Boursorama;
		private System.Windows.Forms.LinkLabel linkLabel_LCL;
		private System.Windows.Forms.LinkLabel linkLabel_CIC;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SiteWebBank));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.linkLabel_CIC = new System.Windows.Forms.LinkLabel();
			this.linkLabel_LCL = new System.Windows.Forms.LinkLabel();
			this.linkLabel_Boursorama = new System.Windows.Forms.LinkLabel();
			this.linkLabel_helloBQ = new System.Windows.Forms.LinkLabel();
			this.linkLabel_BfB = new System.Windows.Forms.LinkLabel();
			this.linkLabel_frconnect = new System.Windows.Forms.LinkLabel();
			this.linkLabel_wiki = new System.Windows.Forms.LinkLabel();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.BackColor = System.Drawing.Color.MediumAquamarine;
			this.groupBox1.Controls.Add(this.linkLabel_CIC);
			this.groupBox1.Controls.Add(this.linkLabel_LCL);
			this.groupBox1.Controls.Add(this.linkLabel_Boursorama);
			this.groupBox1.Controls.Add(this.linkLabel_helloBQ);
			this.groupBox1.Controls.Add(this.linkLabel_BfB);
			this.groupBox1.Controls.Add(this.linkLabel_frconnect);
			this.groupBox1.Controls.Add(this.linkLabel_wiki);
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox1.ForeColor = System.Drawing.SystemColors.Window;
			this.groupBox1.Location = new System.Drawing.Point(0, 1);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(556, 376);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Les autres sites Bancaires";
			// 
			// linkLabel_CIC
			// 
			this.linkLabel_CIC.BackColor = System.Drawing.Color.MediumAquamarine;
			this.linkLabel_CIC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_CIC.Location = new System.Drawing.Point(49, 256);
			this.linkLabel_CIC.Name = "linkLabel_CIC";
			this.linkLabel_CIC.Size = new System.Drawing.Size(397, 31);
			this.linkLabel_CIC.TabIndex = 6;
			this.linkLabel_CIC.TabStop = true;
			this.linkLabel_CIC.Text = "Crédit industriel et commercial (CIC)";
			this.linkLabel_CIC.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_CICLinkClicked);
			// 
			// linkLabel_LCL
			// 
			this.linkLabel_LCL.BackColor = System.Drawing.Color.MediumAquamarine;
			this.linkLabel_LCL.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_LCL.Location = new System.Drawing.Point(49, 225);
			this.linkLabel_LCL.Name = "linkLabel_LCL";
			this.linkLabel_LCL.Size = new System.Drawing.Size(397, 31);
			this.linkLabel_LCL.TabIndex = 5;
			this.linkLabel_LCL.TabStop = true;
			this.linkLabel_LCL.Text = "Crédit Lyonnais";
			this.linkLabel_LCL.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_LCLLinkClicked);
			// 
			// linkLabel_Boursorama
			// 
			this.linkLabel_Boursorama.BackColor = System.Drawing.Color.MediumAquamarine;
			this.linkLabel_Boursorama.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_Boursorama.Location = new System.Drawing.Point(49, 194);
			this.linkLabel_Boursorama.Name = "linkLabel_Boursorama";
			this.linkLabel_Boursorama.Size = new System.Drawing.Size(397, 31);
			this.linkLabel_Boursorama.TabIndex = 4;
			this.linkLabel_Boursorama.TabStop = true;
			this.linkLabel_Boursorama.Text = "Boursorama";
			this.linkLabel_Boursorama.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_BoursoramaLinkClicked);
			// 
			// linkLabel_helloBQ
			// 
			this.linkLabel_helloBQ.BackColor = System.Drawing.Color.MediumAquamarine;
			this.linkLabel_helloBQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_helloBQ.Location = new System.Drawing.Point(49, 163);
			this.linkLabel_helloBQ.Name = "linkLabel_helloBQ";
			this.linkLabel_helloBQ.Size = new System.Drawing.Size(397, 31);
			this.linkLabel_helloBQ.TabIndex = 3;
			this.linkLabel_helloBQ.TabStop = true;
			this.linkLabel_helloBQ.Text = "Hello bank!";
			this.linkLabel_helloBQ.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_helloBQLinkClicked);
			// 
			// linkLabel_BfB
			// 
			this.linkLabel_BfB.BackColor = System.Drawing.Color.MediumAquamarine;
			this.linkLabel_BfB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_BfB.Location = new System.Drawing.Point(49, 132);
			this.linkLabel_BfB.Name = "linkLabel_BfB";
			this.linkLabel_BfB.Size = new System.Drawing.Size(397, 31);
			this.linkLabel_BfB.TabIndex = 2;
			this.linkLabel_BfB.TabStop = true;
			this.linkLabel_BfB.Text = "B for BANK";
			this.linkLabel_BfB.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_BfBLinkClicked);
			// 
			// linkLabel_frconnect
			// 
			this.linkLabel_frconnect.BackColor = System.Drawing.Color.MediumAquamarine;
			this.linkLabel_frconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_frconnect.Location = new System.Drawing.Point(49, 101);
			this.linkLabel_frconnect.Name = "linkLabel_frconnect";
			this.linkLabel_frconnect.Size = new System.Drawing.Size(397, 31);
			this.linkLabel_frconnect.TabIndex = 1;
			this.linkLabel_frconnect.TabStop = true;
			this.linkLabel_frconnect.Text = "Banque Postale";
			this.linkLabel_frconnect.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_frconnectLinkClicked);
			// 
			// linkLabel_wiki
			// 
			this.linkLabel_wiki.BackColor = System.Drawing.Color.MediumAquamarine;
			this.linkLabel_wiki.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_wiki.Location = new System.Drawing.Point(49, 70);
			this.linkLabel_wiki.Name = "linkLabel_wiki";
			this.linkLabel_wiki.Size = new System.Drawing.Size(397, 31);
			this.linkLabel_wiki.TabIndex = 0;
			this.linkLabel_wiki.TabStop = true;
			this.linkLabel_wiki.Text = "Orange Bank";
			this.linkLabel_wiki.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_wikiLinkClicked);
			// 
			// SiteWebBank
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(554, 377);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximumSize = new System.Drawing.Size(570, 416);
			this.MinimumSize = new System.Drawing.Size(570, 416);
			this.Name = "SiteWebBank";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Sites Web Bank";
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
