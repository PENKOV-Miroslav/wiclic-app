﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 13/06/2022
 * Heure: 13:24
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Windows.Forms;

namespace ApplicationWiclic
{
	/// <summary>
	/// Description of Websites.
	/// </summary>
	public partial class Websites : Form
	{
		public Websites()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		//Les boutons ci-dessous permettent l'ouverture des pages web des sites populaire pour les clients
		void Bouton_poleEmploiClick(object sender, EventArgs e)
		{
			try {
					System.Diagnostics.Process.Start("https://www.pole-emploi.fr/accueil/");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
			
		}
		void Bouton_ameliClick(object sender, EventArgs e)
		{
			try {
					System.Diagnostics.Process.Start("https://www.ameli.fr/");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_ImpotsGouvClick(object sender, EventArgs e)
		{
			try {
					System.Diagnostics.Process.Start("https://www.impots.gouv.fr/accueil");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_gouvClick(object sender, EventArgs e)
		{
			try {
					System.Diagnostics.Process.Start("https://www.gouvernement.fr/");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
	
		}
		void Bouton_ifosRetraiteClick(object sender, EventArgs e)
		{
		 	try {
					System.Diagnostics.Process.Start("https://www.index-education.com/fr/");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_urssafClick(object sender, EventArgs e)
		{
			try {
					System.Diagnostics.Process.Start("https://www.urssaf.fr/portail/home.html");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

		}
		void Bouton_creditagrClick(object sender, EventArgs e)
		{
			try {
					System.Diagnostics.Process.Start("https://www.credit-agricole.fr/");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_bnpClick(object sender, EventArgs e)
		{
			try {
					System.Diagnostics.Process.Start("https://group.bnpparibas/");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_caisseEpaClick(object sender, EventArgs e)
		{
				try {
					System.Diagnostics.Process.Start("https://www.caisse-epargne.fr/");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_bankpopClick(object sender, EventArgs e)
		{
				try {
					System.Diagnostics.Process.Start("https://www.banquepopulaire.fr/");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_socGenClick(object sender, EventArgs e)
		{
				try {
					System.Diagnostics.Process.Start("https://particuliers.societegenerale.fr/");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_credMutClick(object sender, EventArgs e)
		{
				try {
					System.Diagnostics.Process.Start("https://www.creditmutuel.fr/home/index.html");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_maafClick(object sender, EventArgs e)
		{
				try {
					System.Diagnostics.Process.Start("https://www.maaf.fr/fr/assurance?=&app=LSM&gclid=6750895ba7b918a2e035ebf3e958cf13&gclsrc=3p.ds&msclkid=6750895ba7b918a2e035ebf3e958cf13&utm_campaign=BA-S-Marque%20MAAF_Marque_Tous&utm_content=Marque_MAAF&utm_medium=cpc&utm_source=bing&utm_term=maaf");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_matmutClick(object sender, EventArgs e)
		{
				try {
					System.Diagnostics.Process.Start("https://www.matmut.fr/#xtor=AL-386-%5Bdefault%5D20190326%5B7500%5D-%5BHome%5D");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_axaClick(object sender, EventArgs e)
		{
				try {
					System.Diagnostics.Process.Start("https://www.axa.fr/?axacid=TRA_Search_Bing_Brand&&msclkid=542a17697aba1b6cc0fa75c1359af0ed&gclid=542a17697aba1b6cc0fa75c1359af0ed&gclsrc=3p.ds");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_groupmaClick(object sender, EventArgs e)
		{
				try {
					System.Diagnostics.Process.Start("https://www.groupama.fr/?xtor=SEC&lm=SEM-GCM-MarqG-groupama_e&gclid=98bcc206117a13e81910a0ae5e316f07&gclsrc=3p.ds");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_directAssuClick(object sender, EventArgs e)
		{
				try {
					System.Diagnostics.Process.Start("https://www.direct-assurance.fr/?&msclkid=1ca1e54c180e1602941987e4576365a7&utm_source=bing&utm_medium=cpc&utm_campaign=SN%20-%20Marque&utm_term=direct%20assurance&utm_content=Marque_Exact&gclid=1ca1e54c180e1602941987e4576365a7&gclsrc=3p.ds");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_allianzClick(object sender, EventArgs e)
		{
				try {
					System.Diagnostics.Process.Start("https://www.allianz.fr/");
				}
			catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
		}
		void Bouton_plusSiteGouvClick(object sender, EventArgs e)
		{

			var SiteWebGouv = new SiteWebGouv();
			SiteWebGouv.ShowDialog();
			SiteWebGouv = null;
			this.Show();
		}
		void Bouton_plusSiteBankClick(object sender, EventArgs e)
		{

			var SiteWebBank = new SiteWebBank();
			SiteWebBank.ShowDialog();
			SiteWebBank = null;
			this.Show();
		}
		void Bouton_plusSiteAssuClick(object sender, EventArgs e)
		{

			var SiteWebAssurance = new SiteWebAssurance();
			SiteWebAssurance.ShowDialog();
			SiteWebAssurance = null;
			this.Show();
		}


	}
}
