﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 20/06/2022
 * Heure: 16:47
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic
{
	partial class SiteWebGouv
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.LinkLabel linkLabel_wiki;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.LinkLabel linkLabel_frconnect;
		private System.Windows.Forms.LinkLabel linkLabel_caf;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SiteWebGouv));
			this.linkLabel_wiki = new System.Windows.Forms.LinkLabel();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.linkLabel_caf = new System.Windows.Forms.LinkLabel();
			this.linkLabel_frconnect = new System.Windows.Forms.LinkLabel();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// linkLabel_wiki
			// 
			this.linkLabel_wiki.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_wiki.Location = new System.Drawing.Point(21, 52);
			this.linkLabel_wiki.Name = "linkLabel_wiki";
			this.linkLabel_wiki.Size = new System.Drawing.Size(492, 31);
			this.linkLabel_wiki.TabIndex = 0;
			this.linkLabel_wiki.TabStop = true;
			this.linkLabel_wiki.Text = "Agence nationale des titres sécurisés (ANTS)";
			this.linkLabel_wiki.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_wikiLinkClicked);
			// 
			// groupBox1
			// 
			this.groupBox1.BackColor = System.Drawing.Color.MediumAquamarine;
			this.groupBox1.Controls.Add(this.linkLabel_caf);
			this.groupBox1.Controls.Add(this.linkLabel_frconnect);
			this.groupBox1.Controls.Add(this.linkLabel_wiki);
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox1.ForeColor = System.Drawing.SystemColors.Window;
			this.groupBox1.Location = new System.Drawing.Point(0, 3);
			this.groupBox1.MinimumSize = new System.Drawing.Size(516, 321);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(545, 357);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Les autres sites du Gouvernement";
			// 
			// linkLabel_caf
			// 
			this.linkLabel_caf.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_caf.Location = new System.Drawing.Point(21, 114);
			this.linkLabel_caf.Name = "linkLabel_caf";
			this.linkLabel_caf.Size = new System.Drawing.Size(492, 31);
			this.linkLabel_caf.TabIndex = 2;
			this.linkLabel_caf.TabStop = true;
			this.linkLabel_caf.Text = "Caisse Allocations Familiales (CAF)";
			this.linkLabel_caf.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_cafLinkClicked);
			// 
			// linkLabel_frconnect
			// 
			this.linkLabel_frconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.linkLabel_frconnect.Location = new System.Drawing.Point(21, 83);
			this.linkLabel_frconnect.Name = "linkLabel_frconnect";
			this.linkLabel_frconnect.Size = new System.Drawing.Size(492, 31);
			this.linkLabel_frconnect.TabIndex = 1;
			this.linkLabel_frconnect.TabStop = true;
			this.linkLabel_frconnect.Text = "France Connect";
			this.linkLabel_frconnect.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel_frconnectLinkClicked);
			// 
			// SiteWebGouv
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(544, 360);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximumSize = new System.Drawing.Size(560, 399);
			this.MinimumSize = new System.Drawing.Size(560, 399);
			this.Name = "SiteWebGouv";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Sites Web Gouv";
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
