﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: m.penkov
 * Date: 13/06/2022
 * Heure: 13:24
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace ApplicationWiclic
{
	partial class Websites
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button bouton_poleEmploi;
		private System.Windows.Forms.Button bouton_ameli;
		private System.Windows.Forms.Button bouton_ImpotsGouv;
		private System.Windows.Forms.Button bouton_gouv;
		private System.Windows.Forms.Button bouton_ifosRetraite;
		private System.Windows.Forms.Button bouton_urssaf;
		private System.Windows.Forms.Button bouton_creditagr;
		private System.Windows.Forms.Button bouton_bnp;
		private System.Windows.Forms.Button bouton_caisseEpa;
		private System.Windows.Forms.Button bouton_bankpop;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button bouton_socGen;
		private System.Windows.Forms.Button bouton_credMut;
		private System.Windows.Forms.Button bouton_allianz;
		private System.Windows.Forms.Button bouton_directAssu;
		private System.Windows.Forms.Button bouton_groupma;
		private System.Windows.Forms.Button bouton_axa;
		private System.Windows.Forms.Button bouton_matmut;
		private System.Windows.Forms.Button bouton_maaf;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.Button bouton_plusSiteGouv;
		private System.Windows.Forms.Button bouton_plusSiteBank;
		private System.Windows.Forms.Button bouton_plusSiteAssu;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Websites));
			this.bouton_poleEmploi = new System.Windows.Forms.Button();
			this.bouton_ameli = new System.Windows.Forms.Button();
			this.bouton_ImpotsGouv = new System.Windows.Forms.Button();
			this.bouton_gouv = new System.Windows.Forms.Button();
			this.bouton_ifosRetraite = new System.Windows.Forms.Button();
			this.bouton_urssaf = new System.Windows.Forms.Button();
			this.bouton_creditagr = new System.Windows.Forms.Button();
			this.bouton_bnp = new System.Windows.Forms.Button();
			this.bouton_caisseEpa = new System.Windows.Forms.Button();
			this.bouton_bankpop = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.bouton_socGen = new System.Windows.Forms.Button();
			this.bouton_credMut = new System.Windows.Forms.Button();
			this.bouton_allianz = new System.Windows.Forms.Button();
			this.bouton_directAssu = new System.Windows.Forms.Button();
			this.bouton_groupma = new System.Windows.Forms.Button();
			this.bouton_axa = new System.Windows.Forms.Button();
			this.bouton_matmut = new System.Windows.Forms.Button();
			this.bouton_maaf = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.bouton_plusSiteGouv = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
			this.bouton_plusSiteBank = new System.Windows.Forms.Button();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
			this.bouton_plusSiteAssu = new System.Windows.Forms.Button();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel2.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.tableLayoutPanel3.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.tableLayoutPanel4.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// bouton_poleEmploi
			// 
			this.bouton_poleEmploi.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_poleEmploi.AutoSize = true;
			this.bouton_poleEmploi.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_poleEmploi.Image = ((System.Drawing.Image)(resources.GetObject("bouton_poleEmploi.Image")));
			this.bouton_poleEmploi.Location = new System.Drawing.Point(3, 3);
			this.bouton_poleEmploi.Name = "bouton_poleEmploi";
			this.bouton_poleEmploi.Size = new System.Drawing.Size(190, 137);
			this.bouton_poleEmploi.TabIndex = 0;
			this.bouton_poleEmploi.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_poleEmploi.UseVisualStyleBackColor = true;
			this.bouton_poleEmploi.Click += new System.EventHandler(this.Bouton_poleEmploiClick);
			// 
			// bouton_ameli
			// 
			this.bouton_ameli.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_ameli.AutoSize = true;
			this.bouton_ameli.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_ameli.Image = ((System.Drawing.Image)(resources.GetObject("bouton_ameli.Image")));
			this.bouton_ameli.Location = new System.Drawing.Point(199, 3);
			this.bouton_ameli.Name = "bouton_ameli";
			this.bouton_ameli.Size = new System.Drawing.Size(190, 137);
			this.bouton_ameli.TabIndex = 1;
			this.bouton_ameli.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_ameli.UseVisualStyleBackColor = true;
			this.bouton_ameli.Click += new System.EventHandler(this.Bouton_ameliClick);
			// 
			// bouton_ImpotsGouv
			// 
			this.bouton_ImpotsGouv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_ImpotsGouv.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_ImpotsGouv.Image = ((System.Drawing.Image)(resources.GetObject("bouton_ImpotsGouv.Image")));
			this.bouton_ImpotsGouv.Location = new System.Drawing.Point(395, 3);
			this.bouton_ImpotsGouv.Name = "bouton_ImpotsGouv";
			this.bouton_ImpotsGouv.Size = new System.Drawing.Size(190, 137);
			this.bouton_ImpotsGouv.TabIndex = 2;
			this.bouton_ImpotsGouv.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_ImpotsGouv.UseVisualStyleBackColor = true;
			this.bouton_ImpotsGouv.Click += new System.EventHandler(this.Bouton_ImpotsGouvClick);
			// 
			// bouton_gouv
			// 
			this.bouton_gouv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_gouv.AutoSize = true;
			this.bouton_gouv.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_gouv.Image = ((System.Drawing.Image)(resources.GetObject("bouton_gouv.Image")));
			this.bouton_gouv.Location = new System.Drawing.Point(591, 3);
			this.bouton_gouv.Name = "bouton_gouv";
			this.bouton_gouv.Size = new System.Drawing.Size(190, 137);
			this.bouton_gouv.TabIndex = 3;
			this.bouton_gouv.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_gouv.UseVisualStyleBackColor = true;
			this.bouton_gouv.Click += new System.EventHandler(this.Bouton_gouvClick);
			// 
			// bouton_ifosRetraite
			// 
			this.bouton_ifosRetraite.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_ifosRetraite.AutoSize = true;
			this.bouton_ifosRetraite.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_ifosRetraite.Image = ((System.Drawing.Image)(resources.GetObject("bouton_ifosRetraite.Image")));
			this.bouton_ifosRetraite.Location = new System.Drawing.Point(787, 3);
			this.bouton_ifosRetraite.Name = "bouton_ifosRetraite";
			this.bouton_ifosRetraite.Size = new System.Drawing.Size(190, 137);
			this.bouton_ifosRetraite.TabIndex = 4;
			this.bouton_ifosRetraite.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_ifosRetraite.UseVisualStyleBackColor = true;
			this.bouton_ifosRetraite.Click += new System.EventHandler(this.Bouton_ifosRetraiteClick);
			// 
			// bouton_urssaf
			// 
			this.bouton_urssaf.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_urssaf.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_urssaf.Image = ((System.Drawing.Image)(resources.GetObject("bouton_urssaf.Image")));
			this.bouton_urssaf.Location = new System.Drawing.Point(983, 3);
			this.bouton_urssaf.Name = "bouton_urssaf";
			this.bouton_urssaf.Size = new System.Drawing.Size(190, 137);
			this.bouton_urssaf.TabIndex = 5;
			this.bouton_urssaf.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_urssaf.UseVisualStyleBackColor = true;
			this.bouton_urssaf.Click += new System.EventHandler(this.Bouton_urssafClick);
			// 
			// bouton_creditagr
			// 
			this.bouton_creditagr.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_creditagr.AutoSize = true;
			this.bouton_creditagr.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_creditagr.Image = ((System.Drawing.Image)(resources.GetObject("bouton_creditagr.Image")));
			this.bouton_creditagr.Location = new System.Drawing.Point(3, 3);
			this.bouton_creditagr.Name = "bouton_creditagr";
			this.bouton_creditagr.Size = new System.Drawing.Size(189, 131);
			this.bouton_creditagr.TabIndex = 6;
			this.bouton_creditagr.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_creditagr.UseVisualStyleBackColor = true;
			this.bouton_creditagr.Click += new System.EventHandler(this.Bouton_creditagrClick);
			// 
			// bouton_bnp
			// 
			this.bouton_bnp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_bnp.AutoSize = true;
			this.bouton_bnp.Image = ((System.Drawing.Image)(resources.GetObject("bouton_bnp.Image")));
			this.bouton_bnp.Location = new System.Drawing.Point(198, 3);
			this.bouton_bnp.Name = "bouton_bnp";
			this.bouton_bnp.Size = new System.Drawing.Size(189, 131);
			this.bouton_bnp.TabIndex = 7;
			this.bouton_bnp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_bnp.UseVisualStyleBackColor = true;
			this.bouton_bnp.Click += new System.EventHandler(this.Bouton_bnpClick);
			// 
			// bouton_caisseEpa
			// 
			this.bouton_caisseEpa.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_caisseEpa.AutoSize = true;
			this.bouton_caisseEpa.Image = ((System.Drawing.Image)(resources.GetObject("bouton_caisseEpa.Image")));
			this.bouton_caisseEpa.Location = new System.Drawing.Point(393, 3);
			this.bouton_caisseEpa.Name = "bouton_caisseEpa";
			this.bouton_caisseEpa.Size = new System.Drawing.Size(189, 131);
			this.bouton_caisseEpa.TabIndex = 8;
			this.bouton_caisseEpa.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_caisseEpa.UseVisualStyleBackColor = true;
			this.bouton_caisseEpa.Click += new System.EventHandler(this.Bouton_caisseEpaClick);
			// 
			// bouton_bankpop
			// 
			this.bouton_bankpop.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_bankpop.Image = ((System.Drawing.Image)(resources.GetObject("bouton_bankpop.Image")));
			this.bouton_bankpop.Location = new System.Drawing.Point(588, 3);
			this.bouton_bankpop.Name = "bouton_bankpop";
			this.bouton_bankpop.Size = new System.Drawing.Size(189, 131);
			this.bouton_bankpop.TabIndex = 9;
			this.bouton_bankpop.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_bankpop.UseVisualStyleBackColor = true;
			this.bouton_bankpop.Click += new System.EventHandler(this.Bouton_bankpopClick);
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.MediumAquamarine;
			this.label1.Dock = System.Windows.Forms.DockStyle.Top;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.SystemColors.Window;
			this.label1.Location = new System.Drawing.Point(0, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(1414, 37);
			this.label1.TabIndex = 10;
			this.label1.Text = "L’avenir est sûr, la protection est notre affaire";
			this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// bouton_socGen
			// 
			this.bouton_socGen.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_socGen.Image = ((System.Drawing.Image)(resources.GetObject("bouton_socGen.Image")));
			this.bouton_socGen.Location = new System.Drawing.Point(783, 3);
			this.bouton_socGen.Name = "bouton_socGen";
			this.bouton_socGen.Size = new System.Drawing.Size(189, 131);
			this.bouton_socGen.TabIndex = 13;
			this.bouton_socGen.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_socGen.UseVisualStyleBackColor = true;
			this.bouton_socGen.Click += new System.EventHandler(this.Bouton_socGenClick);
			// 
			// bouton_credMut
			// 
			this.bouton_credMut.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_credMut.AutoSize = true;
			this.bouton_credMut.Image = ((System.Drawing.Image)(resources.GetObject("bouton_credMut.Image")));
			this.bouton_credMut.Location = new System.Drawing.Point(978, 3);
			this.bouton_credMut.Name = "bouton_credMut";
			this.bouton_credMut.Size = new System.Drawing.Size(189, 131);
			this.bouton_credMut.TabIndex = 14;
			this.bouton_credMut.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_credMut.UseVisualStyleBackColor = true;
			this.bouton_credMut.Click += new System.EventHandler(this.Bouton_credMutClick);
			// 
			// bouton_allianz
			// 
			this.bouton_allianz.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_allianz.AutoSize = true;
			this.bouton_allianz.Image = ((System.Drawing.Image)(resources.GetObject("bouton_allianz.Image")));
			this.bouton_allianz.Location = new System.Drawing.Point(978, 3);
			this.bouton_allianz.Name = "bouton_allianz";
			this.bouton_allianz.Size = new System.Drawing.Size(189, 145);
			this.bouton_allianz.TabIndex = 21;
			this.bouton_allianz.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_allianz.UseVisualStyleBackColor = true;
			this.bouton_allianz.Click += new System.EventHandler(this.Bouton_allianzClick);
			// 
			// bouton_directAssu
			// 
			this.bouton_directAssu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_directAssu.AutoSize = true;
			this.bouton_directAssu.Image = ((System.Drawing.Image)(resources.GetObject("bouton_directAssu.Image")));
			this.bouton_directAssu.Location = new System.Drawing.Point(783, 3);
			this.bouton_directAssu.Name = "bouton_directAssu";
			this.bouton_directAssu.Size = new System.Drawing.Size(189, 145);
			this.bouton_directAssu.TabIndex = 20;
			this.bouton_directAssu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_directAssu.UseVisualStyleBackColor = true;
			this.bouton_directAssu.Click += new System.EventHandler(this.Bouton_directAssuClick);
			// 
			// bouton_groupma
			// 
			this.bouton_groupma.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_groupma.AutoSize = true;
			this.bouton_groupma.Image = ((System.Drawing.Image)(resources.GetObject("bouton_groupma.Image")));
			this.bouton_groupma.Location = new System.Drawing.Point(588, 3);
			this.bouton_groupma.Name = "bouton_groupma";
			this.bouton_groupma.Size = new System.Drawing.Size(189, 145);
			this.bouton_groupma.TabIndex = 18;
			this.bouton_groupma.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_groupma.UseVisualStyleBackColor = true;
			this.bouton_groupma.Click += new System.EventHandler(this.Bouton_groupmaClick);
			// 
			// bouton_axa
			// 
			this.bouton_axa.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_axa.AutoSize = true;
			this.bouton_axa.Image = ((System.Drawing.Image)(resources.GetObject("bouton_axa.Image")));
			this.bouton_axa.Location = new System.Drawing.Point(393, 3);
			this.bouton_axa.Name = "bouton_axa";
			this.bouton_axa.Size = new System.Drawing.Size(189, 145);
			this.bouton_axa.TabIndex = 17;
			this.bouton_axa.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_axa.UseVisualStyleBackColor = true;
			this.bouton_axa.Click += new System.EventHandler(this.Bouton_axaClick);
			// 
			// bouton_matmut
			// 
			this.bouton_matmut.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_matmut.AutoSize = true;
			this.bouton_matmut.Image = ((System.Drawing.Image)(resources.GetObject("bouton_matmut.Image")));
			this.bouton_matmut.Location = new System.Drawing.Point(198, 3);
			this.bouton_matmut.Name = "bouton_matmut";
			this.bouton_matmut.Size = new System.Drawing.Size(189, 145);
			this.bouton_matmut.TabIndex = 16;
			this.bouton_matmut.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_matmut.UseVisualStyleBackColor = true;
			this.bouton_matmut.Click += new System.EventHandler(this.Bouton_matmutClick);
			// 
			// bouton_maaf
			// 
			this.bouton_maaf.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_maaf.AutoSize = true;
			this.bouton_maaf.Image = ((System.Drawing.Image)(resources.GetObject("bouton_maaf.Image")));
			this.bouton_maaf.Location = new System.Drawing.Point(3, 3);
			this.bouton_maaf.Name = "bouton_maaf";
			this.bouton_maaf.Size = new System.Drawing.Size(189, 145);
			this.bouton_maaf.TabIndex = 15;
			this.bouton_maaf.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_maaf.UseVisualStyleBackColor = true;
			this.bouton_maaf.Click += new System.EventHandler(this.Bouton_maafClick);
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.BackColor = System.Drawing.SystemColors.Window;
			this.groupBox1.Controls.Add(this.tableLayoutPanel2);
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.groupBox1.Location = new System.Drawing.Point(3, 3);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1386, 174);
			this.groupBox1.TabIndex = 22;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Les sites du Gouvernement :";
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.tableLayoutPanel2.ColumnCount = 7;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel2.Controls.Add(this.bouton_poleEmploi, 0, 0);
			this.tableLayoutPanel2.Controls.Add(this.bouton_plusSiteGouv, 6, 0);
			this.tableLayoutPanel2.Controls.Add(this.bouton_ameli, 1, 0);
			this.tableLayoutPanel2.Controls.Add(this.bouton_urssaf, 5, 0);
			this.tableLayoutPanel2.Controls.Add(this.bouton_ImpotsGouv, 2, 0);
			this.tableLayoutPanel2.Controls.Add(this.bouton_ifosRetraite, 4, 0);
			this.tableLayoutPanel2.Controls.Add(this.bouton_gouv, 3, 0);
			this.tableLayoutPanel2.Location = new System.Drawing.Point(6, 25);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 1;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(1374, 143);
			this.tableLayoutPanel2.TabIndex = 7;
			// 
			// bouton_plusSiteGouv
			// 
			this.bouton_plusSiteGouv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_plusSiteGouv.BackColor = System.Drawing.SystemColors.Window;
			this.bouton_plusSiteGouv.Image = ((System.Drawing.Image)(resources.GetObject("bouton_plusSiteGouv.Image")));
			this.bouton_plusSiteGouv.Location = new System.Drawing.Point(1179, 3);
			this.bouton_plusSiteGouv.Name = "bouton_plusSiteGouv";
			this.bouton_plusSiteGouv.Size = new System.Drawing.Size(192, 137);
			this.bouton_plusSiteGouv.TabIndex = 6;
			this.bouton_plusSiteGouv.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_plusSiteGouv.UseVisualStyleBackColor = true;
			this.bouton_plusSiteGouv.Click += new System.EventHandler(this.Bouton_plusSiteGouvClick);
			// 
			// groupBox2
			// 
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox2.BackColor = System.Drawing.SystemColors.Window;
			this.groupBox2.Controls.Add(this.tableLayoutPanel3);
			this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
			this.groupBox2.Location = new System.Drawing.Point(3, 183);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(1386, 168);
			this.groupBox2.TabIndex = 23;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Les sites des Banques :";
			// 
			// tableLayoutPanel3
			// 
			this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.tableLayoutPanel3.ColumnCount = 7;
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel3.Controls.Add(this.bouton_creditagr, 0, 0);
			this.tableLayoutPanel3.Controls.Add(this.bouton_plusSiteBank, 6, 0);
			this.tableLayoutPanel3.Controls.Add(this.bouton_bnp, 1, 0);
			this.tableLayoutPanel3.Controls.Add(this.bouton_credMut, 5, 0);
			this.tableLayoutPanel3.Controls.Add(this.bouton_caisseEpa, 2, 0);
			this.tableLayoutPanel3.Controls.Add(this.bouton_socGen, 4, 0);
			this.tableLayoutPanel3.Controls.Add(this.bouton_bankpop, 3, 0);
			this.tableLayoutPanel3.Location = new System.Drawing.Point(9, 25);
			this.tableLayoutPanel3.Name = "tableLayoutPanel3";
			this.tableLayoutPanel3.RowCount = 1;
			this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel3.Size = new System.Drawing.Size(1371, 137);
			this.tableLayoutPanel3.TabIndex = 16;
			// 
			// bouton_plusSiteBank
			// 
			this.bouton_plusSiteBank.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_plusSiteBank.Image = ((System.Drawing.Image)(resources.GetObject("bouton_plusSiteBank.Image")));
			this.bouton_plusSiteBank.Location = new System.Drawing.Point(1173, 3);
			this.bouton_plusSiteBank.Name = "bouton_plusSiteBank";
			this.bouton_plusSiteBank.Size = new System.Drawing.Size(195, 131);
			this.bouton_plusSiteBank.TabIndex = 15;
			this.bouton_plusSiteBank.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_plusSiteBank.UseVisualStyleBackColor = true;
			this.bouton_plusSiteBank.Click += new System.EventHandler(this.Bouton_plusSiteBankClick);
			// 
			// groupBox3
			// 
			this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox3.BackColor = System.Drawing.SystemColors.Window;
			this.groupBox3.Controls.Add(this.tableLayoutPanel4);
			this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
			this.groupBox3.Location = new System.Drawing.Point(3, 357);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(1386, 173);
			this.groupBox3.TabIndex = 24;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Les sites des Assureurs:";
			// 
			// tableLayoutPanel4
			// 
			this.tableLayoutPanel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.tableLayoutPanel4.ColumnCount = 7;
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel4.Controls.Add(this.bouton_maaf, 0, 0);
			this.tableLayoutPanel4.Controls.Add(this.bouton_plusSiteAssu, 6, 0);
			this.tableLayoutPanel4.Controls.Add(this.bouton_matmut, 1, 0);
			this.tableLayoutPanel4.Controls.Add(this.bouton_allianz, 5, 0);
			this.tableLayoutPanel4.Controls.Add(this.bouton_axa, 2, 0);
			this.tableLayoutPanel4.Controls.Add(this.bouton_directAssu, 4, 0);
			this.tableLayoutPanel4.Controls.Add(this.bouton_groupma, 3, 0);
			this.tableLayoutPanel4.Location = new System.Drawing.Point(6, 22);
			this.tableLayoutPanel4.Name = "tableLayoutPanel4";
			this.tableLayoutPanel4.RowCount = 1;
			this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel4.Size = new System.Drawing.Size(1371, 151);
			this.tableLayoutPanel4.TabIndex = 23;
			// 
			// bouton_plusSiteAssu
			// 
			this.bouton_plusSiteAssu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.bouton_plusSiteAssu.Image = ((System.Drawing.Image)(resources.GetObject("bouton_plusSiteAssu.Image")));
			this.bouton_plusSiteAssu.Location = new System.Drawing.Point(1173, 3);
			this.bouton_plusSiteAssu.Name = "bouton_plusSiteAssu";
			this.bouton_plusSiteAssu.Size = new System.Drawing.Size(195, 145);
			this.bouton_plusSiteAssu.TabIndex = 22;
			this.bouton_plusSiteAssu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.bouton_plusSiteAssu.UseVisualStyleBackColor = true;
			this.bouton_plusSiteAssu.Click += new System.EventHandler(this.Bouton_plusSiteAssuClick);
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.MediumAquamarine;
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.groupBox3, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.groupBox2, 0, 1);
			this.tableLayoutPanel1.Location = new System.Drawing.Point(11, 49);
			this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 3;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.89513F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.77153F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(1392, 533);
			this.tableLayoutPanel1.TabIndex = 25;
			// 
			// Websites
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumAquamarine;
			this.ClientSize = new System.Drawing.Size(1414, 593);
			this.Controls.Add(this.tableLayoutPanel1);
			this.Controls.Add(this.label1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(1038, 556);
			this.Name = "Websites";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Websites";
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel2.ResumeLayout(false);
			this.tableLayoutPanel2.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.tableLayoutPanel3.ResumeLayout(false);
			this.tableLayoutPanel3.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.tableLayoutPanel4.ResumeLayout(false);
			this.tableLayoutPanel4.PerformLayout();
			this.tableLayoutPanel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
